package oracle.java.s20200503.service;



import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import oracle.java.s20200503.dao.ReservationDao;
import oracle.java.s20200503.model.Movie;
import oracle.java.s20200503.model.Reservation;
import oracle.java.s20200503.model.Screen;
import oracle.java.s20200503.model.ScreenMovie;

@Service
public class ReservationServiceImpl implements ReservationService{
	
	@Autowired
	private ReservationDao rd;
	
	@Override
	public List<Reservation> resMovie() {
		System.out.println("ReservationServiceImpl...resMovie");
		return rd.resMovie();
	}
	
	@Override
	public List<Reservation> resScreen(int m_num) {
		System.out.println("ReservationServiceImpl...resScreen");
		return rd.resScreen(m_num);
	}

	@Override
	public List<Screen> movScreen(int m_num) {
		System.out.println("ServiceImpl movScreen()");
		return rd.movScreen(m_num);
	}

	@Override
	public List<ScreenMovie> searchDate(Map<String, Integer> map) {
		return rd.searchDate(map);
	}

	@Override
	public List<Reservation> resCalender(int m_num) {
		return rd.resCalender(m_num);
	}

	@Override
	public List<Reservation> getCalender(Map<String, Integer> map) {
		return rd.getCalender(map);
	}

	@Override
	public List<Reservation> searchTime(Map<String, Integer> map) {
		return rd.searchTiem(map);
	}

	@Override
	public int reservation(Map<String, String> map) {
		return rd.reservation(map);
	}

	@Override
	public List<Reservation> seat(String sc_num) {
		return rd.seat(sc_num);
	}

	@Override
	public List<Reservation> seatSelect(Map<String, String> map) {
		return rd.seatSelect(map);
	}

	@Override
	public int resInsert(Map<String, String> resMap) {
		return rd.resInsert(resMap);
	}

	@Override
	public int bsInsert(Map<String, String> bsMap) {
		return rd.bsInsert(bsMap);
	}

	@Override
	public List<Reservation> getTime(Map<String, Integer> map) {
		System.out.println("RSI start...");
		return rd.getTime(map);
	}

	@Override
	public String res_r_num(Map<String, String> resMap) {
		return rd.res_r_num(resMap);
	}

	@Override
	public List<Reservation> bookedSeat(Map<String, String> map) {
		return rd.bookedSeat(map);
	}

	@Override
	public List<Reservation> resDay(Map<String, Integer> map) {
		return rd.resDay(map);
	}

	@Override
	public int totalPrice(String s_num) {
		return rd.totalPrice(s_num);
	}

	@Override
	public List<Reservation> resList(String res_r_num) {
		return rd.resList(res_r_num);
	}

	/*@Override
	public List<Reservation> bookedSeat1(Map<String, String> map) {
		return rd.bookedSeat1(map);
	}*/


	





	
	
}
