package oracle.java.s20200503.dao;

import oracle.java.s20200503.model.Report;

public interface ReportDao {

	int rpCount(Report report);

}
