package oracle.java.s20200503.model;

import com.fasterxml.jackson.annotation.JsonFormat;

//��ũ��_��ȭ �������̺�
public class ScreenMovie {
	private int m_num;	
	private int sc_num;
	@JsonFormat(shape= JsonFormat.Shape.STRING, pattern="yyyy-MM-dd", timezone="Asia/Seoul")
	private String s_start;	
	@JsonFormat(shape= JsonFormat.Shape.STRING, pattern="yyyy-MM-dd", timezone="Asia/Seoul")
	private String s_end;	
	private String s_theater;
	
	public String getS_theater() {
		return s_theater;
	}
	public void setS_theater(String s_theater) {
		this.s_theater = s_theater;
	}
	public int getM_num() {
		return m_num;
	}
	public void setM_num(int m_num) {
		this.m_num = m_num;
	}
	public int getSc_num() {
		return sc_num;
	}
	public void setSc_num(int sc_num) {
		this.sc_num = sc_num;
	}
	public String getS_start() {
		return s_start;
	}
	public void setS_start(String s_start) {
		this.s_start = s_start;
	}
	public String getS_end() {
		return s_end;
	}
	public void setS_end(String s_end) {
		this.s_end = s_end;
	}
	
}
