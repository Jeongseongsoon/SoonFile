package oracle.java.s20200503.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import oracle.java.s20200503.model.Movie;
import oracle.java.s20200503.model.Reservation;
import oracle.java.s20200503.model.Screen;
import oracle.java.s20200503.model.ScreenMovie;


@Repository
public class ReservationDaoImpl implements ReservationDao {
	
	@Autowired
	private SqlSession session;
	
	@Override
	public List<Reservation> resMovie() {
		System.out.println("ReservationDaoImpl......resMovie");
		return session.selectList("resMovie");
	}
	
	@Override
	public List<Reservation> resScreen(int m_num) {
		System.out.println("ReservationDaoImpl.....resScreen");
		return session.selectList("resScreen", m_num);
	}

	@Override
	public List<Screen> movScreen(int m_num) {
		System.out.println("daoImpl movScreen()");
		return session.selectList("movScreen", m_num);
	}
	
	@Override
	public List<ScreenMovie> searchDate(Map<String, Integer> map) {
		return session.selectList("searchDate", map);
	}

	@Override
	public List<Reservation> resCalender(int m_num) {
		return session.selectList("resCalender",m_num);
	}

	@Override
	public List<Reservation> getCalender(Map<String, Integer> map) {
		return session.selectList("getCalender",map);
	}

	@Override
	public List<Reservation> searchTiem(Map<String, Integer> map) {
		return session.selectList("searchTime", map);
	}

	@Override
	public int reservation(Map<String, String> map) {
		return session.insert("reservationInsert", map);
	}

	@Override
	public List<Reservation> seat(String sc_num) {
		return session.selectList("seatCol", sc_num);
	}

	@Override
	public List<Reservation> seatSelect(Map<String, String> map) {
		return session.selectList("seatSelect",map);
	}

	@Override
	public int resInsert(Map<String, String> resMap) {
		return session.insert("resInsert",resMap);
	}

	@Override
	public int bsInsert(Map<String, String> bsMap) {
		return session.insert("bsInsert",bsMap);
	}

	@Override
	public List<Reservation> getTime(Map<String, Integer> map) {
		System.out.println("resDaoIMPL......getTime");
		return session.selectList("getTime",map);
	}

	@Override
	public String res_r_num(Map<String, String> resMap) {
		return session.selectOne("res_r_num",resMap);
	}

	@Override
	public List<Reservation> bookedSeat(Map<String, String> map) {
		return session.selectList("bookedSeat", map);
	}

	@Override
	public List<Reservation> resDay(Map<String, Integer> map) {
		return session.selectList("resDay", map);
	}

	@Override
	public int totalPrice(String s_num) {
		return session.selectOne("totalPrice", s_num);
	}

	@Override
	public List<Reservation> resList(String res_r_num) {
		return session.selectList("resList", res_r_num);
	}

	/*@Override
	public List<Reservation> bookedSeat1(Map<String, String> map) {
		return session.selectList("bookedSeat1", map);
	}*/

	


}
