package oracle.java.s20200503.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import oracle.java.s20200503.model.Comm;
import oracle.java.s20200503.model.Movie;

@Repository
public class MovieDaoImpl implements MovieDao {
	
	@Autowired
	private SqlSession session;	//db connection

	@Override
	public List<Movie> topList(Movie movie) {
		return session.selectList("movieTopList", movie);
	}

	@Override
	public String getM_synop(int m_num) {
		return session.selectOne("getM_synop", m_num);
	}
	
	@Override
	public List<Movie> list(Movie movie) {
		return session.selectList("MovieList", movie);
	}

	@Override
	public List<Movie> movieSearch(String m_title) {
		return session.selectList("movieSearch", m_title);
	}

	@Override
	public Movie trailer(int m_num) {
		System.out.println("MovieDaoImpl trailer m_num->"+m_num);
		return session.selectOne("trailer", m_num);
	}

	@Override
	public String getM_img(int m_num) {
		return session.selectOne("getM_img", m_num);
	}

	@Override
	public Movie detail(int m_num) {
		System.out.println("MovieDaoImpl detail m_num->"+m_num);
		return session.selectOne("detail", m_num);
	}

	@Override
	public String synop(int m_num) {
		System.out.println("MovieDaoImpl synop");
		return session.selectOne("synop", m_num);
	}

	@Override
	public List<Movie> poster(int m_num) {
		System.out.println("MovieDaoImpl poster");
		return session.selectList("poster", m_num);
	}

	/*@Override
	public int bmCheck(Map<String, Integer> map) {
		return session.selectOne("bmCheck", map);
	}

	@Override
	public int bmUpdate(Map<String, Integer> map) {
		System.out.println("MovieDaoImpl bmUpdate()");
		return session.insert("bmUpdate", map);
	}

	@Override
	public int bmDelete(Map<String, Integer> map) {
		System.out.println("MovieDaoImpl bmDelete()");
		return session.delete("bmDelete", map);
	}

	@Override
	public List<Integer> bm(int u_num) {
		return session.selectList("bm", u_num);
	}*/

	@Override
	public List<Comm> carousel() {
		return session.selectList("carousel");
	}
	
	@Override
	public Movie movieList(int mNum) {
		return session.selectOne("mList", mNum);
	}








}
