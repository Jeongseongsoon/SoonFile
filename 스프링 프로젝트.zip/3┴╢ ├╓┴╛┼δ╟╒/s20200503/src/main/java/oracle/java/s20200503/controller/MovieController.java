package oracle.java.s20200503.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import oracle.java.s20200503.model.Movie;
import oracle.java.s20200503.service.MovieService;



@Controller
public class MovieController {
	@Autowired
	private MovieService ms;
	
	@RequestMapping("/movie")
	public String movie(Movie movie, Model model) {
		List<Movie> movieList = ms.list(movie);
		model.addAttribute("MovieList", movieList);
		
		return "movie";
	}
	
	//?
	/*@RequestMapping("usersMovie")
	public String usersMovie(Movie movie, int u_num, Model model) {
		List<Movie> movieList = ms.list(movie);
		model.addAttribute("MovieList", movieList);
		
		System.out.println("MovieController "+u_num);
		List<Integer> bm = ms.bm(u_num);
		model.addAttribute("bm", bm);
	
		return "movie";
	}*/
	
	@RequestMapping(value = "movieDetail", produces = "application/text;charset=UTF-8")
	public String movieDetail(HttpServletRequest request, int m_num, Model model) {
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
		System.out.println("MovieController movieDetail()");
		
		Movie movie = ms.detail(m_num);
		
		model.addAttribute("movie", movie);
		
		return "movieDetail";
	}
	
	// 줄거리 맵핑
	@RequestMapping(value = "synop", produces = "application/text;charset=UTF-8")
	@ResponseBody
	public String synop(int m_num, Model model) {
		System.out.println("m_num->"+ m_num);
		return ms.synop(m_num);
	}
	
	@RequestMapping("/poster")
	@ResponseBody
	public List<Movie> poster(int m_num, Model model) {
		System.out.println("m_num->"+ m_num);
		return ms.poster(m_num);
	}
	
	//완지
	/*@RequestMapping("/bookmark")
	@ResponseBody
	public int bmCheck(int m_num, int u_num, Model model) {
		System.out.println("bookmark 컨트롤러 start");
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("m_num", m_num);
		map.put("u_num", u_num);
		
		int result = ms.bmCheck(map);

		return result;
	}*/
	
	//완지
	/*@RequestMapping("/bmCheck")
	@ResponseBody
	public int bmCheck(int m_num, int u_num, Model model) {
		System.out.println("bookmark 컨트롤러 start");
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("m_num", m_num);
		map.put("u_num", u_num);
		
		int result = ms.bmCheck(map);

		return result;
	}*/
}












