package oracle.java.s20200503.model;

//����� �¼�
public class BookedSeat {
	private int r_num;	//���� ��ȣ
	private int s_num;	//�¼� ��ȣ
	private int sc_num;	//��ũ�� ��ȣ
	
	public int getR_num() {
		return r_num;
	}
	public void setR_num(int r_num) {
		this.r_num = r_num;
	}
	public int getS_num() {
		return s_num;
	}
	public void setS_num(int s_num) {
		this.s_num = s_num;
	}
	public int getSc_num() {
		return sc_num;
	}
	public void setSc_num(int sc_num) {
		this.sc_num = sc_num;
	}
	
}
