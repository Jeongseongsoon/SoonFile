package oracle.java.s20200503.service;

import oracle.java.s20200503.model.Report;

public interface ReportService {

	int rpCount(Report report);

}
