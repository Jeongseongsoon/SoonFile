package oracle.java.s20200503.model;

import java.util.ArrayList;

public class Movie {
	private int m_num;	
	private String m_title;
	private String m_synop;	
	private int m_age;
	private String m_trailer;
	private String m_stDate;
	
	private String bigCate;
	private String midCate;
	private String content;
	
	private ArrayList<String> actorContent;
	private ArrayList<String> genreContent;
	private ArrayList<String> imgContent;
	
	//조회용
	private int u_num;
	
	
	public int getU_num() {
		return u_num;
	}
	public void setU_num(int u_num) {
		this.u_num = u_num;
	}
	public int getM_num() {
		return m_num;
	}
	public void setM_num(int m_num) {
		this.m_num = m_num;
	}
	public String getM_title() {
		return m_title;
	}
	public void setM_title(String m_title) {
		this.m_title = m_title;
	}
	public String getM_synop() {
		return m_synop;
	}
	public void setM_synop(String m_synop) {
		this.m_synop = m_synop;
	}
	public int getM_age() {
		return m_age;
	}
	public void setM_age(int m_age) {
		this.m_age = m_age;
	}
	public String getM_trailer() {
		return m_trailer;
	}
	public void setM_trailer(String m_trailer) {
		this.m_trailer = m_trailer;
	}
	public String getM_stDate() {
		return m_stDate;
	}
	public void setM_stDate(String m_stDate) {
		this.m_stDate = m_stDate;
	}
	public String getBigCate() {
		return bigCate;
	}
	public void setBigCate(String bigCate) {
		this.bigCate = bigCate;
	}
	public String getMidCate() {
		return midCate;
	}
	public void setMidCate(String midCate) {
		this.midCate = midCate;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public ArrayList<String> getActorContent() {
		return actorContent;
	}
	public void setActorContent(ArrayList<String> actorContent) {
		this.actorContent = actorContent;
	}
	public ArrayList<String> getGenreContent() {
		return genreContent;
	}
	public void setGenreContent(ArrayList<String> genreContent) {
		this.genreContent = genreContent;
	}
	public ArrayList<String> getImgContent() {
		return imgContent;
	}
	public void setImgContent(ArrayList<String> imgContent) {
		this.imgContent = imgContent;
	}
	

 	
}
