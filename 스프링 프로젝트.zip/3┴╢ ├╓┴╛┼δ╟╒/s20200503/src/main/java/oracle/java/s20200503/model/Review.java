package oracle.java.s20200503.model;

public class Review {
	private int rw_num;
	private int u_num;
	private String rw_content;
	private int rw_starPoint;
	private int m_num;
	private int rp_count;
	private String rw_time;

	

	// 조회용
	private String search;
	private String keyword;
	private String pageNum;	
	private int start;		
	private int end;
	private String u_id;	// 리뷰 작성자 본인 ID

	public String getU_id() {
		return u_id;
	}

	public void setU_id(String u_id) {
		this.u_id = u_id;
	}

	public String getSearch() {
		return search;
	}

	public void setSearch(String search) {
		this.search = search;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getPageNum() {
		return pageNum;
	}

	public void setPageNum(String pageNum) {
		this.pageNum = pageNum;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getEnd() {
		return end;
	}

	public void setEnd(int end) {
		this.end = end;
	}

	public int getRw_num() {
		return rw_num;
	}

	public void setRw_num(int rw_num) {
		this.rw_num = rw_num;
	}

	public int getU_num() {
		return u_num;
	}

	public void setU_num(int u_num) {
		this.u_num = u_num;
	}

	public String getRw_content() {
		return rw_content;
	}

	public void setRw_content(String rw_content) {
		this.rw_content = rw_content;
	}

	public int getRw_starPoint() {
		return rw_starPoint;
	}

	public void setRw_starPoint(int rw_starPoint) {
		this.rw_starPoint = rw_starPoint;
	}

	public int getM_num() {
		return m_num;
	}

	public void setM_num(int m_num) {
		this.m_num = m_num;
	}

	public int getRp_count() {
		return rp_count;
	}

	public void setRp_count(int rp_count) {
		this.rp_count = rp_count;
	}
	
	public String getRw_time() {
		return rw_time;
	}

	public void setRw_time(String rw_time) {
		this.rw_time = rw_time;
	}

}
