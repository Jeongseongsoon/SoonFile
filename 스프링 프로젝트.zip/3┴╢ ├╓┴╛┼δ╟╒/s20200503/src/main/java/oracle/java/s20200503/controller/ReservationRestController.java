package oracle.java.s20200503.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParser;

import oracle.java.s20200503.model.Reservation;
import oracle.java.s20200503.model.ScreenMovie;
import oracle.java.s20200503.service.ReservationService;

@RestController
@RequestMapping("/resRC")
public class ReservationRestController {
	
	@Autowired
	private ReservationService rs;
	
	@RequestMapping("/res_MovieList")
	public List<Reservation> getListMovie() {
		List<Reservation> movieList = rs.resMovie();
			
		return movieList;
	}
	
	@RequestMapping("/res_ScreenList")
	public List<Reservation> getListscreen(int m_num){
		List<Reservation> movieList = rs.resScreen(m_num);
		
		return movieList;
	}
	
	//완지
	@RequestMapping("/searchDate")
	public List<ScreenMovie> searchDate(int sc_num, int m_num, Model model){

		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("sc_num", sc_num);
		map.put("m_num", m_num);
		
		List<ScreenMovie> sDate = rs.searchDate(map);

		System.out.println("type ->"+sDate.getClass());
		System.out.println(sDate.get(0).getS_start());
		
		return sDate;
	}
	
	@RequestMapping("/res_DayList")
	public List<Reservation> getListDay(int sc_num, int m_num){
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("sc_num", sc_num);
		map.put("m_num", m_num);
		
		List<Reservation> movieList = rs.resDay(map);
		return movieList;
	}	
	
	@RequestMapping("/getCalender")
	public List<Reservation> getCalender(int sc_num, int m_num){
		
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("sc_num", sc_num);
		map.put("m_num", m_num);
		
		List<Reservation> sDate = rs.getCalender(map);
		
		System.out.println("type->" + sDate.getClass());
		System.out.println(sDate.get(0).getS_start());		
		return sDate;
	}
	
	@RequestMapping("/searchTime")
	public List<Reservation> searchTime(int m_num, int sc_num, Model model){
		System.out.println("sc_num-> "+sc_num);
		System.out.println("m_num-> "+m_num);
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("sc_num", sc_num);
		map.put("m_num", m_num);
		
		List<Reservation> sTime = rs.searchTime(map);
		model.addAttribute("searchTime", sTime);
		return sTime;
	}
	
	@RequestMapping("/getTime")
	public List<Reservation> getTime(int sc_num, int m_num, String r_movDate){
		System.out.println("ReservateionRestController getTime Start...");
		System.out.println("sc_num: "+sc_num);
		System.out.println("m_num: "+m_num);
		System.out.println("r_movDate: "+r_movDate);
		
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("sc_num", sc_num);
		map.put("m_num", m_num);
		
		
		//List<Reservation> movieList = rs.getTime(map);
		List<Reservation> movieList = rs.getTime(map);

		
		
		return movieList;
	}
	
	
}











