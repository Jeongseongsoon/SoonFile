package oracle.java.s20200503.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import oracle.java.s20200503.dao.UsersDao;
import oracle.java.s20200503.model.Reservation;
import oracle.java.s20200503.model.Users;

@Service
public class UsersServiceImpl implements UsersService {
	
	@Autowired
	private UsersDao ud;
	
	
	@Override
	public int usersJoin(Users users) {
		System.out.println("UsersServiceImpl usersJoin Start...");
		
		return ud.usersJoin(users);
	}



	@Override
	public Users usersLoginConfi(Users users) {
		System.out.println("UsersServiceImpl usersLoginConfi Start...");
		
		Users loginUser = ud.usersSelect(users);
		
		return loginUser;
	}

	

	@Override
	public int confirmId(String u_id) {
		System.out.println("UsersServiceImpl confirmId Start...");

		int confirmId = ud.confirmId(u_id);
		
		return confirmId;
	}



	@Override
	public Users userSelectInfo(int u_num) {
		System.out.println("UsersServiceImpl userSelectInfo Start...");
		
		Users userInfo = ud.userSelectInfo(u_num);
		
		return userInfo;
	}



	@Override
	public void userUpdate(Users users) {
		System.out.println("UsersServiceImpl userUpdate Start...");
		ud.userUpdate(users);
	}



	@Override
	public List<Reservation> userRes(String u_id) {
		System.out.println("UsersServiceImpl userRes Start...");
		System.out.println("UsersServiceImpl" + u_id);
		
		List<Reservation> userRes = ud.userRes(u_id);
		// TODO Auto-generated method stub
		return userRes;
	}

	//이메일 난수 만들기
	/*private String init() {
		System.out.println("UsersServiceImpl init Start...");

		Random random = new Random();
		StringBuffer sb = new StringBuffer();
		int num = 0;
		
		do {
			// 0~75 사이의 랜덤 수  + 48
			num = random.nextInt(75) + 48;
			if ((num >= 48 && num <= 57) || (num >= 65 && num <= 90) || (num >= 97 && num <= 122)) {
				sb.append((char) num);
			} else {
				continue;
			}
			
			
		} while (sb.length() < size);
		
		if (lowerCheck) {
			return sb.toString().toLowerCase();
		}
		
		System.out.println("UsersServiceImpl init End...");
		return sb.toString();
	}*/
	
	
	
	/*private boolean lowerCheck;
	private int size;

	public String getKey(boolean lowerCheck, int size) {
		System.out.println("UsersServiceImpl getKey Start...");

		this.lowerCheck = lowerCheck;
		this.size = size;
		
		System.out.println("UsersServiceImpl getKey End...");

		return init();
	}*/




	
	
/*	@Override
	public void mailSendWithUserKey(Users users, HttpServletRequest request) {
		System.out.println("UsersServiceImpl mailSendWithUserKey Start...");

		String key = getKey(false, 20);
		
		System.out.println("1");
		System.out.println("1");
		ud.GetKey(users.getU_id(), key);
		System.out.println("1");
		MimeMessage mail = mailSender.createMimeMessage();
		System.out.println("1");
		System.out.println("UsersServiceImpl 메일 보내기 전... Start...");
		
		String htmlStr = "<h2>안녕하세요 MS :p 민수르~ 입니다!</h2><br><br>" 
				+ "<h3>" + users.getU_id() + "님</h3>" + "<p>인증하기 버튼을 누르시면 로그인을 하실 수 있습니다 : " 
				+ "<a href='http://localhost:8080" + request.getContextPath() + "/user/key_alter?user_id="+ users.getU_id() +"&user_key="+key+"'>인증하기</a></p>"
				+ "(혹시 잘못 전달된 메일이라면 이 이메일을 무시하셔도 됩니다)";
		try {
			mail.setSubject("[본인인증] MS :p 민수르님의 인증메일입니다", "utf-8");
			mail.setText(htmlStr, "utf-8", "html");
			mail.addRecipient(RecipientType.TO, new InternetAddress(users.getU_email()));
			mailSender.send(mail);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}
	@Override
	public int alter_usersKey_service(String u_id, String key) {
		int resultCnt = 0;
		
		ud = sqlSession.getMapper(UsersDao.class);
		resultCnt = ud.alter_userKey(u_id, key);
		return 0;
	}*/

	
	
}
