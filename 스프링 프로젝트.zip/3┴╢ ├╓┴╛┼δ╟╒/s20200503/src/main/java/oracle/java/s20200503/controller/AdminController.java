package oracle.java.s20200503.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import oracle.java.s20200503.model.AdminUserMovieReservation;
import oracle.java.s20200503.model.MovieReviewReport;
import oracle.java.s20200503.model.Report;
import oracle.java.s20200503.model.Reservation;
import oracle.java.s20200503.model.Review;
import oracle.java.s20200503.model.Users;
import oracle.java.s20200503.service.AdminService;

import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;
import org.springframework.mail.javamail.MimeMessageHelper;

@Controller
public class AdminController {
	@Autowired
	private AdminService as;
	@Autowired
	private JavaMailSender mailSender; // Spring F/W

	// 페이지 이동 및 기본값 설정
	@RequestMapping(value = "admin_page")
	public String admin_page(String admin_page_num, Model model) {
		
		try {
			System.out.println("admin_page_num start... ");
			int page_num = Integer.parseInt(admin_page_num);
			System.out.println("admin_page_num -> " + page_num);
			if (page_num == 1) {
				// 매출정보 표출
				int sales_count = as.sales_count(); // 총 누적 판매 티켓
				List<Integer> sales_price = as.sales_price(); // 총 매출액
				int sales_price_result = 0;
			
					for (int i = 0; i < sales_price.size(); i++) {
						if(sales_price.get(i) != null) {
							sales_price_result += (Integer) sales_price.get(i);
						}else {
							System.out.println("sales_price 에 값이 없습니다.");
						}
					}
				
				model.addAttribute("sales_price", sales_price_result);
				model.addAttribute("sales_count", sales_count);

			} else if (page_num == 2) {
				// 신고관리
				List<MovieReviewReport> report_list = as.report_list();
				model.addAttribute("report_list", report_list);

			} else if (page_num == 3) {
				// 영화관리
				List<AdminUserMovieReservation> admin_movie_list = as.admin_movie_list();
				for (int i = 0; i < admin_movie_list.size(); i++) {
					int admin_mvrs_count = as.admin_mvrs_count(admin_movie_list.get(i).getM_num());
					admin_movie_list.get(i).setReservation_cnt(admin_mvrs_count);
				}

				model.addAttribute("admin_movie_list", admin_movie_list);

			} else if (page_num == 4) {
				// 유저관리&메일보내기
				List<AdminUserMovieReservation> admin_users_list = as.admin_users_list();

				model.addAttribute("admin_users_list", admin_users_list);
			}

			model.addAttribute("admin_tag_num", admin_page_num);

		} catch (Exception e) {
			e.getStackTrace();
			System.out.println("Admin controller admin_page error => " + e.getMessage());
		}
		return "admin_folder/admin_page";
	}

	// 연별 매출 조회
	@RequestMapping(value = "year_search")
	@ResponseBody
	public Reservation year_search(String selected_year) throws ParseException {
		Reservation rv = new Reservation();
		try {
			System.out.println("AdminController year_search 선택된 연도 = " + selected_year);
			int sales_price = 0;
			List<Integer> year_search_list = as.year_search_price(selected_year);
			int year_search_count = as.year_search_count(selected_year);
			System.out.println("연도가 들어간 후 DB에서 가져오는 값 = " + year_search_count);

			for (int i = 0; i < year_search_list.size(); i++) {
				sales_price += (Integer) year_search_list.get(i);
			}

			rv.setTotal_tiket(year_search_count);
			rv.setTotal_sales(sales_price);

		} catch (Exception e) {
			e.getStackTrace();
			System.out.println("Admin controller year_search error => " + e.getMessage());
		}
		return rv;
	}

	// 월별 매출 조회
	@RequestMapping(value = "month_search")
	@ResponseBody
	public Reservation month_search(String selected_month_year, String selected_month_month) throws ParseException {
		Reservation rv = new Reservation();
		System.out.println("AdminController month_search 선택된 연도 = " + selected_month_year);
		System.out.println("AdminController month_search 선택된 월 = " + selected_month_month);
		try {
			if (Integer.parseInt(selected_month_month) < 10) {
				selected_month_month = "0" + selected_month_month;
			}

			String yearmonth = selected_month_year + selected_month_month;
			int sales_price = 0;

			List<Integer> month_search_list = as.month_search_price(yearmonth);
			int month_search_count = as.month_search_count(yearmonth);

			for (int i = 0; i < month_search_list.size(); i++) {
				sales_price += (Integer) month_search_list.get(i);
			}

			rv.setTotal_tiket(month_search_count);
			rv.setTotal_sales(sales_price);

		} catch (Exception e) {
			e.getStackTrace();
			System.out.println("Admin controller month_search error => " + e.getMessage());
		}

		return rv;
	}

	// 일별 매출 조회
	@RequestMapping(value = "day_search")
	@ResponseBody
	public Reservation day_search(String selected_day) {
		System.out.println("AdminController day_search 선택된 날짜 = " + selected_day);
		Reservation rv = new Reservation();
		int sales_price = 0;
		List<Integer> day_search_list = as.day_search_list(selected_day);
		int day_search_count = as.day_search_count(selected_day);
		for (int i = 0; i < day_search_list.size(); i++) {
			sales_price += (Integer) day_search_list.get(i);
		}

		rv.setTotal_tiket(day_search_count);
		rv.setTotal_sales(sales_price);

		return rv;
	}

	// 리뷰 작성자 정보 조회
	@RequestMapping(value = "user_rw_impormation")
	@ResponseBody
	public List<Review> user_rw_impormation(String u_num) {
		System.out.println("받아오는 회원 번호 값 === " + u_num);
		List<Review> user_rw_impormation_list = as.user_rw_impormation_list(u_num);

		return user_rw_impormation_list;
	}

	// 리뷰 작성자 밴
	@RequestMapping(value = "user_ben")
	@ResponseBody
	public int user_ben(String u_num, String g_num) {
		int result = 0;
		if (Integer.parseInt(g_num) == 1) {
			result = 1;
		} else if (Integer.parseInt(g_num) == 9) {
			result = 0;
		}
		as.ben(u_num, Integer.parseInt(g_num));
		return result;
	}

	// 신고자 정보 조회
	@RequestMapping(value = "user_rp_impormation")
	@ResponseBody
	public List<Report> user_rp_impormation(String u_num) {
		System.out.println("받아오는 회원 번호 값 === " + u_num);
		List<Report> user_rp_impormation_list = as.user_rp_impormation_list(u_num);
		for (int i = 0; i < user_rp_impormation_list.size(); i++) {
			System.out.println("user_rp_impormation_list >>>>>>>> " + user_rp_impormation_list.get(i).getRp_title());
		}

		return user_rp_impormation_list;
	}

	// 신고자 밴
	@RequestMapping(value = "rp_user_ben")
	@ResponseBody
	public int rp_user_ben(String u_num, String g_num) {
		int result = 0;
		if (Integer.parseInt(g_num) == 1) {
			result = 1;
		} else if (Integer.parseInt(g_num) == 9) {
			result = 0;
		}
		as.ben(u_num, Integer.parseInt(g_num));
		return result;
	}

	// 신고관리 검색
	@RequestMapping(value = "admin_search")
	@ResponseBody
	public List<MovieReviewReport> admin_search(HttpServletRequest request) {
		List<MovieReviewReport> admin_search_list = null;
		int select = Integer.parseInt(request.getParameter("admin_search_select"));
		String content = request.getParameter("admin_search_content");

		try {
			if (select == 1) {
				admin_search_list = as.admin_search_list(content, select);
				System.out.println("AdminController admin_search admin_search_list after.....");
				for (int i = 0; i < admin_search_list.size(); i++) {
				}

			} else if (select == 2) {
				admin_search_list = as.admin_search_list(content, select);
			} else if (select == 3) {
				admin_search_list = as.admin_search_list(content, select);
			} else if (select == 4) {
				admin_search_list = as.admin_search_list(content, select);
			} else {
				System.out.println("아무것도 안맞니?");
			}
		} catch (Exception e) {
			e.getStackTrace();
			System.out.println("Admin controller admin_search error => " + e.getMessage());
		}

		return admin_search_list;
	}

	// 관리자 메일 전송
	@RequestMapping(value = "admin_send_email")
	@ResponseBody
	public int admin_send_email(HttpServletRequest request, Model model) {
		int result = 0;
		String u_email = request.getParameter("u_email"); // 받는 회원의 email
		String setfrom = "springtest9202@gmail.com"; // 보내는 관리자 아이디
		String em_title = request.getParameter("em_title"); // 받아오는 메일 제목
		String em_content = request.getParameter("em_content"); // 받아오는 메일 내용
		try {
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper messageHelper = new MimeMessageHelper(message, true, "UTF-8");
			messageHelper.setFrom(setfrom); // 보내는사람 생략하거나 하면 정상작동을 안함
			messageHelper.setTo(u_email); // 받는사람 이메일
			messageHelper.setSubject(em_title); // 메일제목은 (생략 가능)
			messageHelper.setText(em_content); // 메일 내용
			mailSender.send(message);

			result = 1; // 메일 정상 전달

		} catch (Exception e) {
			System.out.println(e);
			result = 2; // 메일 전달 실패
		}
		return result;
	}

	// 관리자 상영 마감
	@RequestMapping(value = "admin_movie_close")
	@ResponseBody
	public int admin_movie_close(String m_num) {
		int result = 0;
		try {
			as.admin_movie_close(m_num);
			result = 1;
		} catch (Exception e) {
			e.getStackTrace();
			System.out.println("Admin_controller admin_movie_close error" + e.getMessage());
		}

		return result;
	}

	// 관리자 영화 등록
	@RequestMapping(value = "admin_insert_movie.do")
	public String admin_insert_movie(Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {
		String admin_theater = request.getParameter("admin_theater");
		String[] admin_genre = request.getParameterValues("admin_genre"); 		// 장르
		String stillcut_num = request.getParameter("stillcut_num");				// 스틸컷 갯수 값을 받아온다
		String admin_m_title = request.getParameter("admin_m_title"); 			// 영화제목
		String admin_m_img = request.getParameter("admin_m_img"); 				// 포스터
		String admin_m_synop = request.getParameter("admin_m_synop"); 			// 줄거리
		String admin_m_age = request.getParameter("admin_m_age"); 				// 연령제한
		String admin_m_trailer = request.getParameter("admin_m_trailer"); 		// 예고편
		String admin_m_stdate = request.getParameter("admin_m_stdate"); 		// 개봉일
		String admin_s_start = request.getParameter("admin_s_start"); 			// 상영시작일
		String admin_s_end = request.getParameter("admin_s_end"); 				// 상영마감일
		String[] admin_stilcut = new String[Integer.parseInt(stillcut_num)];	// 스틸컷을 담을 배열을 생성한다.
		for (int i = 0; i < Integer.parseInt(stillcut_num); i++) {
			admin_stilcut[i] = request.getParameter("admin_stilcut" + Integer.toString(i));	// 받아온 스틸컷을 반복문으로 배열에 저장한다.
		}

		AdminUserMovieReservation aumr = new AdminUserMovieReservation();
		
		try {
			// 영화 데이터 생성
			aumr.setM_title(admin_m_title);
			aumr.setM_synop(admin_m_synop);
			aumr.setM_age(Integer.parseInt(admin_m_age));
			aumr.setM_trailer(admin_m_trailer);
			aumr.setM_stdate(java.sql.Date.valueOf(admin_m_stdate));
			as.admin_insert_movie(aumr);
			
			// 상영 시간 생성
			aumr.setS_start(java.sql.Date.valueOf(admin_s_start));
			aumr.setS_end(java.sql.Date.valueOf(admin_s_end));
			aumr.setSc_num(Integer.parseInt(admin_theater));
			as.admin_insert_sm(aumr);
			
			// 장르 생성
			aumr.setBigcate(10);
			for (String m : admin_genre) {
				aumr.setMidcate(Integer.parseInt(m));
				as.admin_genre_insert(aumr);
			}
			
			// 포스터 생성
			aumr.setBigcate(20);
			aumr.setContent(admin_m_img);
			as.admin_m_img_insert2(aumr);		// common 테이블에사진 생성
			as.admin_m_img_insert(aumr);		// 중간 테이블 경로 생성
			
			// 스틸컷 생성
			aumr.setBigcate(30);
			for (String m :admin_stilcut) {
				// 배열에 있는 스틸컷 정보를 model에 set해준 뒤 DB에 저장 (담겨져 있는 스틸컷의 개수 만큼 반복 저장)
				aumr.setContent(m);
				as.admin_common_insert(aumr);		// common 테이블에 사진 생성
				as.admin_stillcut_insert(aumr);		// 중간 테이블 경로 생성
			}
		} catch (Exception e) {
			e.getStackTrace();
			System.out.println("Admin_controller admin_insert_movie error" + e.getMessage());
		}
		redirectAttributes.addAttribute("admin_page_num", "3");	// 관리자 페이지로 리다이렉션시 가져갈 페이지 넘버 값 전달
		return "redirect:admin_page.do";
	}

	// 관리자 영화 정보 수정을 위한 데이터 조회
	@RequestMapping(value="movie_lookup")
	@ResponseBody
	public AdminUserMovieReservation movie_lookup(HttpServletRequest request, Model model){
		AdminUserMovieReservation aumr = new AdminUserMovieReservation();
		String m_num = request.getParameter("m_num");
		String sc_num = request.getParameter("sc_num");
		aumr.setM_num(Integer.parseInt(m_num));
		aumr.setSc_num(Integer.parseInt(sc_num));
		System.out.println("m_num = "+m_num);
		System.out.println("sc_num = "+ sc_num);
		// 영화, 상영관, 포스터, 스크린무비 테이블 정보 조회
		aumr = as.admin_movie_update_select(aumr);
		return aumr;
	}
	
	@RequestMapping(value="admin_update_movie")
	public String admin_update_movie(Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {
		String admin_update_m_num		= request.getParameter("admin_update_m_num");			// 영화 번호
		String admin_update_theater 	= request.getParameter("admin_update_theater"); 		// 상영관
		String admin_update_m_title 	= request.getParameter("admin_update_m_title"); 		// 영화제목
		String admin_update_poster 		= request.getParameter("admin_update_poster"); 			// 포스터
		String admin_update_synop 		= request.getParameter("admin_update_synop"); 			// 줄거리
		String admin_update_m_age 		= request.getParameter("admin_update_m_age"); 			// 연령제한
		String admin_update_m_trailer 	= request.getParameter("admin_update_m_trailer"); 		// 예고편
		String admin_update_m_stdate 	= request.getParameter("admin_update_m_stdate"); 		// 개봉일
		String admin_update_s_start 	= request.getParameter("admin_update_s_start"); 		// 상영시작일
		String admin_update_s_end 		= request.getParameter("admin_update_s_end"); 			// 상영마감일
		String[] admin_update_genre 	= request.getParameterValues("admin_update_genre"); 			// 장르
		String update_stillcut_num 		= request.getParameter("update_stillcut_num");			// 스틸컷 갯수 값을 받아온다
		String[] admin_stilcut 			= new String[Integer.parseInt(update_stillcut_num)];			// 스틸컷을 담을 배열을 생성한다.
		for (int i = 0; i < Integer.parseInt(update_stillcut_num); i++) {
			admin_stilcut[i] = request.getParameter("admin_update_stilcut" + Integer.toString(i));	// 받아온 스틸컷을 반복문으로 배열에 저장한다.
		}
		/*System.out.println("admin_update_m_num = "+admin_update_m_num);
		System.out.println("admin_update_theater = "+admin_update_theater);
		System.out.println("admin_update_m_title = "+admin_update_m_title);
		System.out.println("admin_update_poster = "+admin_update_poster);
		System.out.println("admin_update_synop = "+admin_update_synop);
		System.out.println("admin_update_m_age = "+admin_update_m_age);
		System.out.println("admin_update_m_trailer = "+admin_update_m_trailer);
		System.out.println("admin_update_m_stdate = "+admin_update_m_stdate);
		System.out.println("admin_update_s_start = "+admin_update_s_start);
		System.out.println("admin_update_s_end = "+admin_update_s_end);
		*/
		AdminUserMovieReservation aumr = new AdminUserMovieReservation();
		aumr.setM_num(Integer.parseInt(admin_update_m_num));
		aumr.setSc_num(Integer.parseInt(admin_update_theater));
		aumr.setM_title(admin_update_m_title);
		aumr.setContent(admin_update_poster);
		aumr.setM_synop(admin_update_synop);
		aumr.setM_age(Integer.parseInt(admin_update_m_age));
		aumr.setM_trailer(admin_update_m_trailer);
		aumr.setM_stdate(java.sql.Date.valueOf(admin_update_m_stdate));
		aumr.setS_start(java.sql.Date.valueOf(admin_update_s_start));
		aumr.setS_end(java.sql.Date.valueOf(admin_update_s_end));
		
		// 영화 수정
		as.admin_movie_update(aumr);
		
		// 장르 생성
		aumr.setBigcate(10);
		for (String m : admin_update_genre) {
			aumr.setMidcate(Integer.parseInt(m));
			as.admin_genre_update(aumr);
		}
								
		// 스틸컷 생성
		aumr.setBigcate(30);
		as.admin_stillcut_delete(aumr);
		as.admin_stillcut_update(aumr, admin_stilcut);
		
		redirectAttributes.addAttribute("admin_page_num", "3");	// 관리자 페이지로 리다이렉션시 가져갈 페이지 넘버 값 전달
		return "redirect:admin_page.do";
	}
}
