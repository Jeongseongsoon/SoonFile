package oracle.java.s20200503.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Repository;

import oracle.java.s20200503.model.Reservation;
import oracle.java.s20200503.model.Users;


@Repository
public class UsersDaoImpl implements UsersDao {

	@Autowired
	private SqlSession session;
	
	@Override
	public int usersJoin(Users users) {
		System.out.println("UsersDaoImple usersJoin Start..");

		
		return session.insert("usersJoin", users);
	}

	@Override
	public Users usersSelect(Users users) {
		System.out.println("UsersDaoImple usersSelect Start..");
		
		
		// TODO Auto-generated method stub
		return session.selectOne("usersSelect", users);
	}

	@Override
	public int confirmId(String u_id) {
		System.out.println("UsersDaoImple confirmId Start..");
		
		return session.selectOne("confirmId", u_id);
	}

	@Override
	public Users userSelectInfo(int u_num) {
		System.out.println("UsersDaoImple userSelectInfo Start..");
	
		return session.selectOne("userInfo", u_num);
	}

	@Override
	public void userUpdate(Users users) {
		System.out.println("UsersDaoImple userUpdate Start..");
		session.update("userUpdate", users);
		
	}

	@Override
	public List<Reservation> userRes(String u_id) {
		System.out.println("UsersDaoImple userRes Start..");
		// TODO Auto-generated method stub
		System.out.println("UsersDaoImple" + u_id);
		return session.selectList("userReservation", u_id);
	}
	


}
