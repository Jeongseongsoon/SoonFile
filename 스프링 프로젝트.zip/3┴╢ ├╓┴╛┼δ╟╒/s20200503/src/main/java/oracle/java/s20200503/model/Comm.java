package oracle.java.s20200503.model;

//장르 분류
public class Comm {
	private int g_num;	//장르 번호
	private String bigCatego;	//대분류
	private String m_genre;	//영화 장르
	
	public int getG_num() {
		return g_num;
	}
	public void setG_num(int g_num) {
		this.g_num = g_num;
	}
	public String getBigCatego() {
		return bigCatego;
	}
	public void setBigCatego(String bigCatego) {
		this.bigCatego = bigCatego;
	}
	public String getM_genre() {
		return m_genre;
	}
	public void setM_genre(String m_genre) {
		this.m_genre = m_genre;
	}
}
