package oracle.java.s20200503.service;

import java.util.List;
import java.util.Map;

import oracle.java.s20200503.model.Movie;
import oracle.java.s20200503.model.Reservation;
import oracle.java.s20200503.model.Screen;
import oracle.java.s20200503.model.ScreenMovie;

public interface ReservationService {

	List<Reservation> resMovie();

	List<Reservation> resScreen(int m_num);

	//완지
	List<Screen> movScreen(int m_num);

	//완지
	List<ScreenMovie> searchDate(Map<String, Integer> map);

	//캘린더
	List<Reservation> resCalender(int m_num);

	List<Reservation> getCalender(Map<String, Integer> map);

	//완지
	List<Reservation> searchTime(Map<String, Integer> map);

	int reservation(Map<String, String> map);

	List<Reservation> seat(String sc_num);

	List<Reservation> seatSelect(Map<String, String> map);

	int resInsert(Map<String, String> resMap);

	int bsInsert(Map<String, String> bsMap);

	List<Reservation> getTime(Map<String, Integer> map);

	String res_r_num(Map<String, String> resMap);

	List<Reservation> bookedSeat(Map<String, String> map);

	List<Reservation> resDay(Map<String, Integer> map);

	int totalPrice(String s_num);

	List<Reservation> resList(String res_r_num);

	//List<Reservation> bookedSeat1(Map<String, String> map);






}
