package oracle.java.s20200503.model;

import java.sql.Date;
import java.util.List;

public class AdminUserMovieReservation {
	private int 		u_num;			// 회원 번호
	private int		 	g_num;			// 회원 등급
	private String 		u_name;			// 회원 이름
	private String 		u_id;			// 회원 아이디	
	private String 		u_email;		// 회원 이메일
	private String 		u_phone;		// 회원 전화번호
	private String 		u_birth;		// 회원 생일
	private int 		u_mile;			// 회원 마일리지

	private int 		m_num;			// 영화번호
	private String 		m_title;		// 영화제목
	private String		m_synop;		// 줄거리
	private int			m_age;			// 연령제한
	private String		m_trailer;		// 예고편
	private Date		m_stdate;		// 영화 개봉일
	
	private Date		s_start;		// 상영 시작일
	private Date		s_end;			// 상영 마감일
	
	private int			sc_num;			// 스크린 번호
	private String		s_theater;		// 상영관
	private int			reservation_cnt;// 예약 카운트
	
	private int			bigcate;		// 대분류
	private int			midcate;		// 중분류
	
	private String		content;		// common 테이블에 넣을 데이터
	
	
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getMidcate() {
		return midcate;
	}
	public void setMidcate(int midcate) {
		this.midcate = midcate;
	}
	public int getBigcate() {
		return bigcate;
	}
	public void setBigcate(int bigcate) {
		this.bigcate = bigcate;
	}
	public String getM_synop() {
		return m_synop;
	}
	public void setM_synop(String m_synop) {
		this.m_synop = m_synop;
	}
	public int getM_age() {
		return m_age;
	}
	public void setM_age(int m_age) {
		this.m_age = m_age;
	}
	public String getM_trailer() {
		return m_trailer;
	}
	public void setM_trailer(String m_trailer) {
		this.m_trailer = m_trailer;
	}
	public Date getM_stdate() {
		return m_stdate;
	}
	public void setM_stdate(Date m_stdate) {
		this.m_stdate = m_stdate;
	}
	public int getSc_num() {
		return sc_num;
	}
	public void setSc_num(int sc_num) {
		this.sc_num = sc_num;
	}
	public int getReservation_cnt() {
		return reservation_cnt;
	}
	public void setReservation_cnt(int reservation_cnt) {
		this.reservation_cnt = reservation_cnt;
	}
	public String getS_theater() {
		return s_theater;
	}
	public void setS_theater(String s_theater) {
		this.s_theater = s_theater;
	}
	public int getU_num() {
		return u_num;
	}
	public void setU_num(int u_num) {
		this.u_num = u_num;
	}
	public int getG_num() {
		return g_num;
	}
	public void setG_num(int g_num) {
		this.g_num = g_num;
	}
	public String getU_name() {
		return u_name;
	}
	public void setU_name(String u_name) {
		this.u_name = u_name;
	}
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public String getU_email() {
		return u_email;
	}
	public void setU_email(String u_email) {
		this.u_email = u_email;
	}
	public String getU_phone() {
		return u_phone;
	}
	public void setU_phone(String u_phone) {
		this.u_phone = u_phone;
	}
	public String getU_birth() {
		return u_birth;
	}
	public void setU_birth(String u_birth) {
		this.u_birth = u_birth;
	}
	public int getU_mile() {
		return u_mile;
	}
	public void setU_mile(int u_mile) {
		this.u_mile = u_mile;
	}
	public int getM_num() {
		return m_num;
	}
	public void setM_num(int m_num) {
		this.m_num = m_num;
	}
	public String getM_title() {
		return m_title;
	}
	public void setM_title(String m_title) {
		this.m_title = m_title;
	}
	public Date getS_start() {
		return s_start;
	}
	public void setS_start(Date s_start) {
		this.s_start = s_start;
	}
	public Date getS_end() {
		return s_end;
	}
	public void setS_end(Date s_end) {
		this.s_end = s_end;
	}

	
}
