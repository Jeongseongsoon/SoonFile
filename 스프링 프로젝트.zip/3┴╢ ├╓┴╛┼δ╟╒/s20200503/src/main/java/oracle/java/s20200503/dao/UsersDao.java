package oracle.java.s20200503.dao;


import java.util.List;

import oracle.java.s20200503.model.Reservation;
import oracle.java.s20200503.model.Users;

public interface UsersDao {

	int usersJoin(Users users);

	Users usersSelect(Users users);

	int confirmId(String u_id);

	Users userSelectInfo(int u_num);

	void userUpdate(Users users);

	List<Reservation> userRes(String u_id);

	

}
