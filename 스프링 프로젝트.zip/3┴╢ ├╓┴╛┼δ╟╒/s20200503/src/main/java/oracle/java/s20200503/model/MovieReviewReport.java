package oracle.java.s20200503.model;

import java.util.List;

public class MovieReviewReport {
	private int				rw_num;			// 리뷰번호
	private int 			u_num;			// 리뷰작성자 번호
	private String 			rw_content;		// 리뷰내용
	private String 			m_num;			// 영화번호(제목)
	private int 			rp_count;		// 신고횟수
	private String			rp_title;		// 신고제목
	private String 			rp_content;		// 신고내용
	private int 			rp_u_num;		// 받아오는 신고한 사람
	private int 			g_num;			// 받아오는 리뷰작성자 회원 등급
	private int 			rp_g_num;		// 받아오는 신고자 회원 등급
	
	private String 			rw_u_name;		// 받아오는 신고당한 유저이름
	private String 			m_title;		// 받아오는 영화제목
	private String 			rp_u_name;		// 받아오는 신고자 이름
	
	
	public int getRp_g_num() {
		return rp_g_num;
	}
	public void setRp_g_num(int rp_g_num) {
		this.rp_g_num = rp_g_num;
	}
	public int getG_num() {
		return g_num;
	}
	public void setG_num(int g_num) {
		this.g_num = g_num;
	}
	public String getRw_u_name() {
		return rw_u_name;
	}
	public void setRw_u_name(String rw_u_name) {
		this.rw_u_name = rw_u_name;
	}
	public int getRw_num() {
		return rw_num;
	}
	public void setRw_num(int rw_num) {
		this.rw_num = rw_num;
	}
	public int getU_num() {
		return u_num;
	}
	public void setU_num(int u_num) {
		this.u_num = u_num;
	}
	public String getRw_content() {
		return rw_content;
	}
	public void setRw_content(String rw_content) {
		this.rw_content = rw_content;
	}
	public String getM_num() {
		return m_num;
	}
	public void setM_num(String m_num) {
		this.m_num = m_num;
	}
	public int getRp_count() {
		return rp_count;
	}
	public void setRp_count(int rp_count) {
		this.rp_count = rp_count;
	}
	public int getRp_u_num() {
		return rp_u_num;
	}
	public void setRp_u_num(int rp_u_num) {
		this.rp_u_num = rp_u_num;
	}
	public String getRp_title() {
		return rp_title;
	}
	public void setRp_title(String rp_title) {
		this.rp_title = rp_title;
	}
	public String getRp_content() {
		return rp_content;
	}
	public void setRp_content(String rp_content) {
		this.rp_content = rp_content;
	}
	public String getM_title() {
		return m_title;
	}
	public void setM_title(String m_title) {
		this.m_title = m_title;
	}
	
	public String getRp_u_name() {
		return rp_u_name;
	}
	public void setRp_u_name(String rp_u_name) {
		this.rp_u_name = rp_u_name;
	}
	
}
