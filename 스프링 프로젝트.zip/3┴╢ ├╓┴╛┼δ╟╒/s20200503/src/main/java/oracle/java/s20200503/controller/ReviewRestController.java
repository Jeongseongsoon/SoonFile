package oracle.java.s20200503.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import oracle.java.s20200503.model.Review;
import oracle.java.s20200503.model.ReviewVO;
import oracle.java.s20200503.service.ReviewService;

// @Controller + @ResponseBody
@RestController
public class ReviewRestController {
	@Autowired
	private ReviewService rs;

   @RequestMapping("/getMovieReview")
   public ReviewVO sendVO2(int u_num, int m_num) {
	  System.out.println("@RestController getMovieReview u_num->"+u_num);
	  System.out.println("@RestController getMovieReview m_num->"+m_num);
	  ReviewVO vo = new ReviewVO();
	  Review review = new Review();
	  review.setU_num(u_num);
	  review.setM_num(m_num);
	  // u_num(사용자)와 m_num(영화번호)를 가지고  Review를 조회하여 기 등록되어 있는지 검증
	  int reviewCnt  = rs.rwOneSelect(review);
	  vo.setMnum(reviewCnt);
//	  vo.setMnum(0);
	  return vo;
	  }	 
    
//   @RequestMapping("/sendVO3")
//   public List<Dept> sendVO3() {
//	System.out.println("@RestController sendVO3  START");
//	List<Dept> deptList = es.select();
//	return deptList;
//	}
//  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
	  
}
