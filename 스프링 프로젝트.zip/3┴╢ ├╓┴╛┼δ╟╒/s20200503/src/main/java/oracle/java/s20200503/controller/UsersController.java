package oracle.java.s20200503.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import oracle.java.s20200503.model.Reservation;
import oracle.java.s20200503.model.Users;
import oracle.java.s20200503.service.UsersService;

@Controller
public class UsersController {
	
	@Autowired
	private UsersService us;

	@RequestMapping(value="usersJoinForm")
	public String usersJoinForm() {
		return "usersJoinForm";
	}
	
	@RequestMapping(value="usersJoin", method = RequestMethod.POST)
	public String userJoin(String u_email_first, String u_email_last, Users users, Model model) {
		System.out.println("UsersController userJoin Start...");
		System.out.println("UsersController userJoin Start..." + u_email_first);
		System.out.println("UsersController userJoin Start..." + u_email_last);
		
		String u_email = u_email_first + "@" + u_email_last;
		users.setU_email(u_email);
		
		int k = us.usersJoin(users);
		
		if (k>0) return "redirect:main.do";
		else return "forward:usersJoinForm.do";
	}
	
	@RequestMapping(value="usersLoginForm")
	public String usersLoginForm() {
		
		return "usersLoginForm";
	}
	
	/*@RequestMapping(value="usersLogin", method = RequestMethod.POST)
	public String usersLogin(Users users,HttpServletRequest request, Model model) {
		Users loginUser = us.usersLoginConfi(users);
		
		int userG_num = loginUser.getG_num();
		
		System.out.println("userG_num-->" + userG_num);
		
		if (loginUser != null && userG_num != 9) {
			HttpSession session = request.getSession();
			
			session.setAttribute("users", loginUser);
			
			return "redirect:main.do";
		} else {
			model.addAttribute("banUser", userG_num);
			return "redirect:usersLoginForm.do";
		}
	}
	*/
	@RequestMapping(value="usersLogin", method = RequestMethod.POST)
	public String usersLogin(Users users,HttpServletRequest request, Model model, RedirectAttributes redirectAttributes) {
		Users loginUser = us.usersLoginConfi(users);
		
		int userG_num = loginUser.getG_num();
		
		System.out.println("userG_num-->" + userG_num);
		
		if (loginUser != null && userG_num != 9) {
			HttpSession session = request.getSession();
			
			session.setAttribute("users", loginUser);
			
			return "redirect:main.do";
		} else {
			model.addAttribute("banUser", userG_num);
			return "usersLoginForm";
		}
	}
	
	@RequestMapping(value="searchAddressPopup")
	public String searchAddressPopup(Model model) {
		System.out.println("UsersController searchAddressPopup Start...");
		
		return "searchAddressPopup";
	}
	
	@RequestMapping(value="myPageForm")
	public String myPageForm() {
		return "myPageForm";
	}
	
	@RequestMapping(value="myPage")
	public String myPage(Users users) {
		us.userUpdate(users);
		
		return "myPageForm";
	}
	
	@RequestMapping(value="logOut")
	public String logOut(HttpServletRequest request) {
		System.out.println("UsersController logOut Start...");
		HttpSession session = request.getSession();
		session.invalidate();
		
		return "redirect:main.do";
	}
	
	@RequestMapping(value="userUpdateForm")
	public String userUpdateForm(HttpServletRequest request, Model model) {
		
		return "userUpdateForm";
	}
	
	@RequestMapping(value="userReservation")
	   public String userReservation(HttpServletRequest request, Model model) {
	      System.out.println("UsersController userReservation Start...");
	      
	      HttpSession session = request.getSession();
	      Users users = (Users)session.getAttribute("users");
	      String u_id = users.getU_id();
	      System.out.println("u_id---->" + users.getU_id());
	      System.out.println();
	      
	      
	      List<Reservation> userRes = us.userRes(u_id);
	      
	      System.out.println("userRes--->" + userRes.get(1));
	      
	      model.addAttribute("userReservation", userRes);
	      
	      return "userReservation";
	   }
	   
}


















