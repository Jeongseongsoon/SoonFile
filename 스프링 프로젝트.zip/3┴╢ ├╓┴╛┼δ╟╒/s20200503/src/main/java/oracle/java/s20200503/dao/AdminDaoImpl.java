package oracle.java.s20200503.dao;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import oracle.java.s20200503.model.AdminUserMovieReservation;
import oracle.java.s20200503.model.MovieReviewReport;
import oracle.java.s20200503.model.Report;
import oracle.java.s20200503.model.Reservation;
import oracle.java.s20200503.model.Review;
import oracle.java.s20200503.model.Users;


@Repository
public class AdminDaoImpl implements AdminDao{
	@Autowired
	private SqlSession session;
	@Override
	public int sales_count() {
		System.out.println("AdminDaoImpl 1 sales_count start............");
		int sCount =0;
		try {
			sCount = session.selectOne("sales_count");
		} catch (Exception e) {
			System.out.println("AdminDaoImpl sales_count e.getMessage()->"+e.getMessage());
		}
		return sCount;
	}
	@Override
	public List<Integer> sales_price() {
		System.out.println("AdminDaoImpl 2 sales_price start............");
		return session.selectList("sales_price");
	}
	@Override
	public List<Integer> year_search_price(String selected_year) {
		System.out.println("AdminDaoImpl 3 year_search_price start............");
		return session.selectList("year_search_price", selected_year);
	}
	@Override
	public int year_search_count(String selected_year) {
		System.out.println("AdminDaoImpl 4 year_search_count start............");
		return session.selectOne("year_search_count", selected_year);
	}
	@Override
	public List<Integer> month_search_price(String yearmonth) {
		System.out.println("AdminDaoImpl 5 month_search_price start............");
		return session.selectList("month_search_price", yearmonth);
	}
	@Override
	public int month_search_count(String yearmonth) {
		System.out.println("AdminDaoImpl 6 month_search_count start............");
		return session.selectOne("month_search_count", yearmonth);
	}
	@Override
	public List<Integer> day_search_list(String selected_day) {
		System.out.println("AdminDaoImpl 7 day_search_list start............");
		return session.selectList("day_search_list", selected_day);
	}
	@Override
	public int day_search_count(String selected_day) {
		System.out.println("AdminDaoImpl 8 day_search_count start............");
		return session.selectOne("day_search_count", selected_day);
	}
	@Override
	public List<MovieReviewReport> report_list() {
		System.out.println("AdminDaoImpl 9 report_list start............");
		return session.selectList("report_list");
	}
	@Override
	public List<Review> user_rw_impormation_list(String u_num) {
		System.out.println("AdminDaoImpl 10 user_rw_impormation_list start............");
		return session.selectList("user_rw_impormation_list", u_num);
	}
	@Override
	public void ben(String u_num, int g_num) {
		System.out.println("AdminDaoImpl 11 ben start............");
		if(g_num == 1) {
			session.update("ben", u_num);
		}else if(g_num == 9) {
			session.update("return_ben", u_num);
		}
	}
	@Override
	public List<Report> user_rp_impormation_list(String u_num) {
		System.out.println("AdminDaoImpl 12 user_rp_impormation_list start............");
		return session.selectList("user_rp_impormation_list", u_num);
	}
	@Override
	public List<MovieReviewReport> admin_search_list(String admin_search_content, int select) {
		System.out.println("AdminDaoImpl 13 admin_search_list start............");
		if(select ==1) {
			return session.selectList("admin_search_list_rw_user", admin_search_content);
		}else if(select ==2) {
			return session.selectList("admin_search_list_rw_num", admin_search_content);
		}else if(select ==3) {
			return session.selectList("admin_search_list_m_title", admin_search_content);
		}else if(select ==4) {
			return session.selectList("admin_search_list_rp_user", admin_search_content);
		}else {
			return null;
		}
	}
	@Override
	public List<AdminUserMovieReservation> admin_users_list() {
		System.out.println("AdminDaoImpl 14 admin_users_list start............");
		return session.selectList("admin_users_list");
	}
	@Override
	public List<AdminUserMovieReservation> admin_movie_list() {
		System.out.println("AdminDaoImpl 15 admin_movie_list start............");
		return session.selectList("admin_movie_list");
	}
	@Override
	public int admin_mvrs_count(int m_num) {
		return session.selectOne("admin_mvrs_count", m_num);
	}
	@Override
	public void admin_movie_close(String m_num) {
		System.out.println("AdminDaoImpl 17 admin_movie_close start............");
		session.update("admin_movie_close", m_num);
	}
	@Override
	public void admin_insert_movie(AdminUserMovieReservation aumr) {
		System.out.println("AdminDaoImpl 18 admin_insert_movie start............");
		session.insert("admin_insert_movie", aumr);
	}
	@Override
	public void admin_insert_sm(AdminUserMovieReservation aumr) {
		System.out.println("AdminDaoImpl 19 admin_insert_sm start............");
		session.insert("admin_insert_sm", aumr);
	}
	@Override
	public void admin_genre_insert(AdminUserMovieReservation aumr) {
		System.out.println("AdminDaoImpl 20 admin_genre_insert start............");
		session.insert("admin_genre_insert", aumr);
	}
	@Override
	public void admin_m_img_insert(AdminUserMovieReservation aumr) {
		System.out.println("AdminDaoImpl 21 admin_m_img_insert start............");
		session.insert("admin_m_img_insert", aumr);
	}
	@Override
	public void admin_m_img_insert2(AdminUserMovieReservation aumr) {
		System.out.println("AdminDaoImpl 22 admin_m_img_insert2 start............");
		session.insert("admin_m_img_insert2", aumr);
	}
	@Override
	public void admin_common_insert(AdminUserMovieReservation aumr) {
		System.out.println("AdminDaoImpl 23 admin_common_insert start............");
		session.insert("admin_common_insert", aumr);
	}
	@Override
	public void admin_stillcut_insert(AdminUserMovieReservation aumr) {
		System.out.println("AdminDaoImpl 24 admin_stillcut_insert start............");
		session.insert("admin_stillcut_insert", aumr);
	}
	@Override
	public AdminUserMovieReservation admin_movie_update_select(AdminUserMovieReservation aumr) {
		System.out.println("AdminDaoImpl 25 admin_movie_update_select start............");
		return session.selectOne("admin_movie_update_select", aumr);
	}
	@Override
	public void admin_movie_update(AdminUserMovieReservation aumr) {
		System.out.println("AdminDaoImpl 26 admin_movie_update start............");
		System.out.println("AdminDaoImpl admin_update_m_num 		= "+aumr.getM_num());
		System.out.println("AdminDaoImpl admin_update_theater 	= "+aumr.getSc_num());
		System.out.println("AdminDaoImpl admin_update_m_title 	= "+aumr.getM_title());
		System.out.println("AdminDaoImpl admin_update_poster 	= "+aumr.getContent());
		System.out.println("AdminDaoImpl admin_update_synop 		= "+aumr.getM_synop());
		System.out.println("AdminDaoImpl admin_update_m_age 		= "+aumr.getM_age());
		System.out.println("AdminDaoImpl admin_update_m_trailer) = "+aumr.getM_trailer());
		System.out.println("AdminDaoImpl admin_update_m_stdate 	= "+aumr.getM_stdate());
		System.out.println("AdminDaoImpl admin_update_s_start 	= "+aumr.getS_start());
		System.out.println("AdminDaoImpl admin_update_s_end 		= "+aumr.getS_end());
		try {
			session.selectOne("admin_movie_update", aumr);
		} catch (Exception e) {
			System.out.println("AdminDaoImpl e.getMessage() =>" + e.getMessage());
		}
		
	}
	@Override
	public void admin_genre_update(AdminUserMovieReservation aumr) {
		System.out.println("AdminDaoImpl 27 admin_genre_update start............");
		session.update("admin_genre_update", aumr);
	}
	@Override
	public void admin_stillcut_delete(AdminUserMovieReservation aumr) {
		System.out.println("AdminDaoImpl 28 admin_stillcut_delete start............");
		List<Integer> stillcut_midcate = session.selectList("lookup_stillcut", aumr);
		for(int midcate : stillcut_midcate) {
			session.delete("admin_stillcut_delete", midcate);
		}
	}
	@Override
	public void admin_stillcut_update(AdminUserMovieReservation aumr, String[] admin_stilcut) {
		System.out.println("AdminDaoImpl 29 admin_stillcut_update start............");
		for (String m : admin_stilcut) {
			aumr.setContent(m);
			session.update("admin_stillcut_update", aumr);
		}
	}
}
