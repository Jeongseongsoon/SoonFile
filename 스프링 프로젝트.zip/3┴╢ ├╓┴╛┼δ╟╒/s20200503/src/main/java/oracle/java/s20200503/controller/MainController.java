package oracle.java.s20200503.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import oracle.java.s20200503.model.Comm;
import oracle.java.s20200503.model.Movie;
import oracle.java.s20200503.service.MovieService;

@Controller
public class MainController {

	@Autowired
	private MovieService ms;
	
	@RequestMapping("/main")
	public String main(Model model, Movie movie) {
		
		List<Movie> movieList = ms.topList(movie);
		model.addAttribute("topMovieList", movieList);
		
		//캐러셀이미지
		List<Comm> carousel = ms.carousel();
		model.addAttribute("carousel", carousel);
		System.out.println("carousel: "+carousel.size());
				
		return "main";
	}
	
	@RequestMapping(value = "getM_synop", produces = "application/text;charset=UTF-8")
	@ResponseBody
	public String getM_synop(int m_num, int i, Model model) {
		System.out.println("get synop m_num -> "+m_num);
		return ms.getM_synop(m_num);
	}
	
	@RequestMapping(value = "getM_img", produces = "application/text;charset=UTF-8")
	@ResponseBody
	public String getM_img(int m_num, int i, Model model) {
		System.out.println(m_num);
		System.out.println("index -> "+i);
		String mImg = ms.getM_img(m_num);
		System.out.println("mImg: "+mImg);
		return mImg;
	}
	
	@RequestMapping("/movieSearch")
	public String movieSearch(Model model, String m_title) {
		
		List<Movie> movieSearch = ms.movieSearch(m_title);
		model.addAttribute("movieSearch", movieSearch);
		model.addAttribute("movieSearchMsg", "현재 상영중인 영화가 없습니다.");
		
		return "movieSearch";
	}
	
	@RequestMapping("/theater")
	public String theate() {
		
		return "theater1";
	}
	
/*	@RequestMapping("/payment")
	public String payment() {
		
		return "payment";
	}*/
	
	

}
