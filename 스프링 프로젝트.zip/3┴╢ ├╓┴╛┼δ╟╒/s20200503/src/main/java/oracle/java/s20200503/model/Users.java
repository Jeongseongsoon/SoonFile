package oracle.java.s20200503.model;

public class Users {
	private int u_num;				// 회원번호
	private String u_name;			// 회원명
	private String u_id;			// 회원아이디
	private String u_passwd;		// 회원비밀번호
	private int g_num;
	
	
	private String u_email;			// 회원이메일
	private String u_email_first;			// 회원이메일
	private String u_email_last;			// 회원이메일
	private String u_phone;			// 연락처
	private int u_birth;			// 생년월일
	private String u_genfav;		// 장르성향도
	private int u_grade;			// 회원등급
	private int u_mile;				// 마일리지
	private String recommand_id;    // 추천 아이디
	private String u_address_postcode;
	private String u_address_roadAddress;
	private String u_address_jibunAddress;
	private String u_address_detailAddress;
	private String u_address_extraAddress;
	private String u_key;
	
	
	
	
	public int getG_num() {
		return g_num;
	}
	public void setG_num(int g_num) {
		this.g_num = g_num;
	}
	public String getRecommand_id() {
		return recommand_id;
	}
	public void setRecommand_id(String recommand_id) {
		this.recommand_id = recommand_id;
	}
	public int getU_num() {
		return u_num;
	}
	public void setU_num(int u_num) {
		this.u_num = u_num;
	}
	public String getU_name() {
		return u_name;
	}
	public void setU_name(String u_name) {
		this.u_name = u_name;
	}
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public String getU_passwd() {
		return u_passwd;
	}
	public void setU_passwd(String u_passwd) {
		this.u_passwd = u_passwd;
	}
	public String getU_email() {
		return u_email;
	}
	public void setU_email(String u_email) {
		this.u_email = u_email;
	}
	public String getU_phone() {
		return u_phone;
	}
	public void setU_phone(String u_phone) {
		this.u_phone = u_phone;
	}
	public int getU_birth() {
		return u_birth;
	}
	public void setU_birth(int u_birth) {
		this.u_birth = u_birth;
	}
	public String getU_genfav() {
		return u_genfav;
	}
	public void setU_genfav(String u_genfav) {
		this.u_genfav = u_genfav;
	}
	
	public int getU_grade() {
		return u_grade;
	}
	public void setU_grade(int u_grade) {
		this.u_grade = u_grade;
	}
	public int getU_mile() {
		return u_mile;
	}
	public void setU_mile(int u_mile) {
		this.u_mile = u_mile;
	}
	public String getU_address_postcode() {
		return u_address_postcode;
	}
	public void setU_address_postcode(String u_address_postcode) {
		this.u_address_postcode = u_address_postcode;
	}
	public String getU_address_roadAddress() {
		return u_address_roadAddress;
	}
	public void setU_address_roadAddress(String u_address_roadAddress) {
		this.u_address_roadAddress = u_address_roadAddress;
	}
	public String getU_address_jibunAddress() {
		return u_address_jibunAddress;
	}
	public void setU_address_jibunAddress(String u_address_jibunAddress) {
		this.u_address_jibunAddress = u_address_jibunAddress;
	}
	public String getU_address_detailAddress() {
		return u_address_detailAddress;
	}
	public void setU_address_detailAddress(String u_address_detailAddress) {
		this.u_address_detailAddress = u_address_detailAddress;
	}
	public String getU_address_extraAddress() {
		return u_address_extraAddress;
	}
	public void setU_address_extraAddress(String u_address_extraAddress) {
		this.u_address_extraAddress = u_address_extraAddress;
	}
	public String getU_key() {
		return u_key;
	}
	public void setU_key(String u_key) {
		this.u_key = u_key;
	}
	
	public String getU_email_first() {
		return u_email_first;
	}
	public void setU_email_first(String u_email_first) {
		this.u_email_first = u_email_first;
	}
	public String getU_email_last() {
		return u_email_last;
	}
	public void setU_email_last(String u_email_last) {
		this.u_email_last = u_email_last;
	}
	
	
}
