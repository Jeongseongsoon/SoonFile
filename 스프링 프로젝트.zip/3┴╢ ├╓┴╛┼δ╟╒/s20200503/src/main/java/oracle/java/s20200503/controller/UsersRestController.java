package oracle.java.s20200503.controller;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import oracle.java.s20200503.service.UsersService;


@RestController
public class UsersRestController {
	
	@Autowired
	private JavaMailSender mailSender;
	
	@Autowired
	private UsersService us;
	
	@RequestMapping(value="userEmailConfirm")
	public String userEmailConfirm(String u_email_first,String u_email_last, Model model) {
		System.out.println("UsersRestController userEmailConfirm start...");
		String setfrom = "leejoowon1988@gamil.com";
		System.out.println("u_email->" + u_email_first + u_email_last);
		String confirmNum="1";
		
		
		try {
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper messageHelper = new MimeMessageHelper(message, true, "utf-8");
			messageHelper.setTo(u_email_first + u_email_last);
			messageHelper.setSubject("이메일 인증번호 발급");
			confirmNum = (int)(Math.random() * 9999999) + 1 + "";
			messageHelper.setText("임시비밀번호 : " + confirmNum);
			messageHelper.setFrom(setfrom);
			mailSender.send(message);
			//model.addAttribute("check", 1);
			model.addAttribute("confirmNum", confirmNum);
			
			
		} catch (Exception e) {
			System.out.println("UsersRestController userEmailConfirm Exception start");
			System.out.println(e.getMessage());
			//model.addAttribute("check", 2);
		}
		System.out.println("confirmNum----------->" + confirmNum);
		return confirmNum;
	}
	
	@RequestMapping(value="userIdConfirm")
	public int userIdConfirm(String u_id) {
		
		int confirmId = us.confirmId(u_id);
		
		
		return confirmId;
	}
	
}
