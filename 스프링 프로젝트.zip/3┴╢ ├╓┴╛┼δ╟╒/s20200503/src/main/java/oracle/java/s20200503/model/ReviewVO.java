package oracle.java.s20200503.model;

public class ReviewVO {

    private Integer mnum;
    private String  strAnswer;
  
	public Integer getMnum() {
		return mnum;
	}
	public void setMnum(Integer mnum) {
		this.mnum = mnum;
	}
	public String getStrAnswer() {
		return strAnswer;
	}
	public void setStrAnswer(String strAnswer) {
		this.strAnswer = strAnswer;
	}
 
  
}
