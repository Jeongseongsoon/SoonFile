package oracle.java.s20200503.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import oracle.java.s20200503.model.Movie;
import oracle.java.s20200503.model.Reservation;
import oracle.java.s20200503.model.Screen;
import oracle.java.s20200503.service.MovieService;
import oracle.java.s20200503.service.ReservationService;

@Controller
public class ReservationController {

	@Autowired
	private ReservationService rs;
	
	@Autowired
	private MovieService ms;

	@RequestMapping("/Reservation1")
	public String Reservation1() {
		System.out.println("rsssssssssssssssssssssss");
		return "Reservation1";
	}

	@RequestMapping(value = "getResM_Movie")
	public Object reservationList(Model model, Reservation reservation) {
		System.out.println("ReservationController....reservationList.......");
		List<Reservation> resMovie = rs.resMovie();
		model.addAttribute("resMovie", resMovie);

		for (int i = 0; i < resMovie.size(); i++) {
			
		}
		return "Reservation1";
	}
	
	@RequestMapping(value="getResS_Screen")
	public String getResS_Screen(Model model, int m_num, Reservation reservation) {
		System.out.println("ReservationController....getResS_Screen.......");
		List<Reservation> resScreen = rs.resScreen(m_num);
		model.addAttribute("m_num", m_num);
		model.addAttribute("resScreen", resScreen);
		
		for (int i = 0; i < resScreen.size(); i++) {
			System.out.println("controller..for start.....");
			System.out.println(resScreen.get(i).getSc_num());
			System.out.println(resScreen.get(i).getS_theater());

		}
		
		return "Reservation1";
	}

	//완지
	@RequestMapping("/movieRes")
	public String movieRes(int m_num, Model model) {
		System.out.println("con movieRes()");
		
		List<Screen> movieScreen = rs.movScreen(m_num);
		model.addAttribute("movScreen", movieScreen);
		
		Movie movie = ms.detail(m_num);
		model.addAttribute("movie", movie);
		
		return "mReservation";
	}

	/*@ResponseBody
	@RequestMapping("/searchDate")
	public List<ScreenMovie> searchDate(int sc_num, int m_num, Model model){
		System.out.println("Rest searchDate()");
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("sc_num", sc_num);
		map.put("m_num", m_num);
		
		List<ScreenMovie> sDate = rs.searchDate(map);
		model.addAttribute("searchDate", sDate);
		System.out.println(sDate.get(0).getS_start());
		
		return sDate;
	}*/
	
/*	//상영시작 및 종료 날짜
	@RequestMapping(value="getResSM_Day")
	public String getResSM_Day(Model model, int m_num, Reservation reservation) {
		List<Reservation> resDay = rs.resDay(m_num);
		model.addAttribute("m_num......."+m_num);
		model.addAttribute("resScreen", resDay);
		
		for (int i = 0; i < resDay.size(); i++) {

		}
		
		return "Reservation1";
	}*/
	
	//
	@RequestMapping(value="getCalender")
	public String getCalender(int m_num, Model model) {
		
		List<Reservation> movieScreen = rs.resCalender(m_num);
		model.addAttribute("movScreen",movieScreen);
		
		return "Reservation1";
	}
	
	//진호
	@RequestMapping("/seatSelect")
	public String seatSelect(String m_num, String sc_num, String r_movDate, String mt_num, Model model) {
		Map<String, String> map = new HashMap<String, String>();

		map.put("m_num", m_num);
		map.put("sc_num", sc_num);
		//map.put("s_num", s_num);
		map.put("r_movDate", r_movDate);
		map.put("mt_num", mt_num);
		
		List<Reservation> listSeat = rs.seatSelect(map);
		
		System.out.println("listSeat.size()-->" +listSeat.size());
		System.out.println(map.get("sc_num"));
		
		model.addAttribute("map", map);
		model.addAttribute("seatSelect",listSeat);
		
		List<Reservation> bookedSeat = rs.bookedSeat(map);
		int bookedCnt = bookedSeat.size();
		System.out.println("bookedCnt----------->>>" + bookedCnt);
		model.addAttribute("bookedSeat", bookedSeat);
		model.addAttribute("bookedCnt", bookedCnt);
		
		System.out.println("dddd: "+bookedSeat.size());
		
		return "Reservation2";
	}
	
	
	/*@RequestMapping("/seatSelect1")
	public String seatSelect1(String m_num, String sc_num, String s_num, String r_movDate, String mt_num, Model model) {
		Map<String, String> map = new HashMap<String, String>();

		map.put("m_num", m_num);
		map.put("sc_num", sc_num);
		map.put("s_num", s_num);
		map.put("r_movDate", r_movDate);
		map.put("mt_num", mt_num);
		
		List<Reservation> listSeat = rs.seatSelect(map);
		
		System.out.println("listSeat.size()-->" +listSeat.size());
		System.out.println(map.get("sc_num"));
		
		model.addAttribute("map", map);
		model.addAttribute("seatSelect",listSeat);
		
		List<Reservation> bookedSeat1 = rs.bookedSeat1(map);
		int bookedCnt = bookedSeat1.size();
		System.out.println("bookedCnt----------->>>" + bookedCnt);
		model.addAttribute("bookedSeat", bookedSeat1);
		model.addAttribute("bookedCnt", bookedCnt);
		
		return "Reservation2";
	}*/
	
	
	
	
	@RequestMapping("/reservation")
	public String reservation(String u_num, String m_num, String sc_num, String mt_stime, String r_movDate, String mt_num) {
		System.out.println(u_num+m_num+sc_num+mt_stime+r_movDate+" "+mt_num);
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("u_num", u_num);
		map.put("m_num", m_num);
		map.put("sc_num", sc_num);
		map.put("mt_stime", mt_stime);
		map.put("r_movDate", r_movDate);
		map.put("mt_num", mt_num);
		
		int result = rs.reservation(map);
		System.out.println("예약 result-> "+result);
		
		if(result >0) {
			return "reservationCheck";
		}else {
			return "redirect:seat";
		}
	}
	
	@RequestMapping("/resInsert")
	public String resInsert(HttpServletRequest request, String r_num, String u_num, String m_num, String sc_num, String s_num, String r_movDate, String mt_num, String r_respeople, Model model) {
		
		//2명이 좌석선택하면 checkList배열 크기 = 2
        String[] checkList = request.getParameterValues("s_num");
        int total = 0;
        int price = 0;
        for(int j=0; j<checkList.length; j++) {
        	s_num = checkList[j];
        	price = rs.totalPrice(s_num);
        	total += price;
        	System.out.println("price: "+price);
        }
        String totalPrice = String.valueOf(total); 
        System.out.println("totalPrice: "+totalPrice);
        
        Map<String, String> resMap = new HashMap<String, String>();
		resMap.put("u_num", u_num);
		resMap.put("m_num", m_num);
		resMap.put("sc_num", sc_num);
		resMap.put("r_movDate", r_movDate);
		resMap.put("mt_num", mt_num);
		resMap.put("r_respeople", r_respeople);
		resMap.put("r_num", r_num);
		resMap.put("p_price1", totalPrice);
		
        int resInsert = rs.resInsert(resMap);
        model.addAttribute("insertAll",resInsert);
        
        //가장 마지막 예약번호 가져오기
        String res_r_num =  rs.res_r_num(resMap);
        
        Map<String, String> bsMap = new HashMap<String, String>();
		System.out.println("s_num: "+s_num);
		
        for(int i=0; i<checkList.length; i++) {
        	bsMap.put("r_num", res_r_num);
        	bsMap.put("s_num", checkList[i]);
        	bsMap.put("sc_num", sc_num);
        	
        	int bsInsert = rs.bsInsert(bsMap);
        	System.out.println("bsInsert->"+bsInsert);
        }
        
        List<Reservation> resList = rs.resList(res_r_num);
        model.addAttribute("resList", resList);
        System.out.println(res_r_num);
        System.out.println("resList: "+resList.get(0).getP_price());
        System.out.println("resList title: "+resList.get(0).getM_title());
        
        //결제화면에서 보여지는 정보
        int mNum = Integer.parseInt(m_num);
        Movie mList = ms.movieList(mNum);
        model.addAttribute("movieList", mList);
        
		return "payment";
	}
	
	/*@RequestMapping("/payment")
	public String payment(HttpServletRequest request, String u_num, String m_num, String sc_num, String s_num, String r_movDate, String mt_num, String r_respeople, Model model) {
		
		Map<String, String> sNum = new HashMap<String, String>();
		
		String[] checkList = request.getParameterValues("s_num");
		
		for(int i = 0; i<checkList.length; i++) {
			sNum.put("s_num", checkList[i]);
			System.out.println("s_num: "+checkList[i]);
		}
		
		for(String mapkey : sNum.keySet()) {
			System.out.println(sNum.get(mapkey));
		}
		
		model.addAttribute("u_num", u_num);
		model.addAttribute("m_num", m_num);
		model.addAttribute("sc_num", sc_num);
		model.addAttribute("s_num", sNum);
		model.addAttribute("r_movDate", r_movDate);
		model.addAttribute("mt_num", mt_num);
		model.addAttribute("r_respeople", r_respeople);
		
		
		
		return "payment";
	}*/

}











