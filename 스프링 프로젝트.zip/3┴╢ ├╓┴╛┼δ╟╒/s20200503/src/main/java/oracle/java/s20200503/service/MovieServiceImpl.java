package oracle.java.s20200503.service;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import oracle.java.s20200503.dao.MovieDao;
import oracle.java.s20200503.model.Comm;
import oracle.java.s20200503.model.Movie;

@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	private MovieDao md;
	
	@Override
	public List<Movie> topList(Movie movie) {
		return md.topList(movie);
	}

	@Override
	public String getM_synop(int m_num) {
		return md.getM_synop(m_num);
	}
	
	@Override
	public List<Movie> list(Movie movie) {
		return md.list(movie);
	}

	@Override
	public List<Movie> movieSearch(String m_title) {
		return md.movieSearch(m_title);
	}

	@Override
	public Movie trailer(int m_num) {
		return md.trailer(m_num);
	}

	@Override
	public String getM_img(int m_num) {
		System.out.println("MovieServiceImpl getM_img m_num->"+ m_num);
		return md.getM_img(m_num);
	}

	@Override
	public Movie detail(int m_num) {
		System.out.println("MovieServiceImpl detail m_num->"+ m_num);
		return md.detail(m_num);
	}

	@Override
	public String synop(int m_num) {
		System.out.println("MovieServiceImpl synop m_num->"+ m_num);
		return md.synop(m_num);
	}

	@Override
	public List<Movie> poster(int m_num) {
		System.out.println("MovieServiceImpl poster m_num->"+ m_num);
		return md.poster(m_num);
	}

	/*@Override
	public int bmCheck(Map<String, Integer> map) {
		return md.bmCheck(map);
	}

	@Override
	public int bmInsert(Map<String, Integer> map) {
		System.out.println("MovieServcieImpl bmInsert()");
		return md.bmUpdate(map);
	}

	@Override
	public int bmDelete(Map<String, Integer> map) {
		System.out.println("MovieServcieImpl bmDelete()");
		 return md.bmDelete(map);
	}

	@Override
	public List<Integer> bm(int u_num) {
		return md.bm(u_num);
	}*/

	@Override
	public List<Comm> carousel() {
		return md.carousel();
	}

	@Override
	public Movie movieList(int mNum) {
		return md.movieList(mNum);
	}








}
