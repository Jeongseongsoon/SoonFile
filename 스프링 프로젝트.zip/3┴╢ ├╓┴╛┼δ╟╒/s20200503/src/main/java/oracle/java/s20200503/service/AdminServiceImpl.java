package oracle.java.s20200503.service;


import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import oracle.java.s20200503.dao.AdminDao;
import oracle.java.s20200503.model.AdminUserMovieReservation;
import oracle.java.s20200503.model.MovieReviewReport;
import oracle.java.s20200503.model.Report;
import oracle.java.s20200503.model.Reservation;
import oracle.java.s20200503.model.Review;
import oracle.java.s20200503.model.Users;



@Service
public class AdminServiceImpl implements AdminService {
	@Autowired
	private AdminDao ad;
	@Override
	public int sales_count() {
		System.out.println("AdminServiceImpl 1 sales_count start.....");
		return ad.sales_count();
	}
	@Override
	public List<Integer> sales_price() {
		System.out.println("AdminServiceImpl 2 sales_price start.....");
		return ad.sales_price();
	}
	@Override
	public List<Integer> year_search_price(String selected_year) {
		System.out.println("AdminServiceImpl 3 year_search_price start.....");
		return ad.year_search_price(selected_year);
	}
	@Override
	public int year_search_count(String selected_year) {
		System.out.println("AdminServiceImpl 4 year_search_count start.....");
		return ad.year_search_count(selected_year);
	}
	@Override
	public List<Integer> month_search_price(String yearmonth) {
		System.out.println("AdminServiceImpl 5 month_search_price start.....");
		return ad.month_search_price(yearmonth);
	}
	@Override
	public int month_search_count(String yearmonth) {
		System.out.println("AdminServiceImpl 6 month_search_count start.....");
		return ad.month_search_count(yearmonth);
	}
	@Override
	public List<Integer> day_search_list(String selected_day) {
		System.out.println("AdminServiceImpl 7 day_search_list start.....");
		return ad.day_search_list(selected_day);
	}
	@Override
	public int day_search_count(String selected_day) {
		System.out.println("AdminServiceImpl 8 day_search_count start.....");
		return ad.day_search_count(selected_day);
	}
	@Override
	public List<MovieReviewReport> report_list() {
		System.out.println("AdminServiceImpl 9 report_list start.....");
		return ad.report_list();
	}
	@Override
	public List<Review> user_rw_impormation_list(String u_num) {
		System.out.println("AdminServiceImpl 10 user_rw_impormation_list start.....");
		return ad.user_rw_impormation_list(u_num);
	}
	@Override
	public void ben(String u_num, int g_num) {
		System.out.println("AdminServiceImpl 11 ben start.....");
		ad.ben(u_num, g_num);
	}
	@Override
	public List<Report> user_rp_impormation_list(String u_num) {
		System.out.println("AdminServiceImpl 12 user_rp_impormation_list start.....");
		return ad.user_rp_impormation_list(u_num);
	}
	@Override
	public List<MovieReviewReport> admin_search_list(String admin_search_content, int select) {
		System.out.println("AdminServiceImpl 13 admin_search_list start.....");
		return ad.admin_search_list(admin_search_content, select);
	}
	@Override
	public List<AdminUserMovieReservation> admin_users_list() {
		System.out.println("AdminServiceImpl 14 admin_users_list start.....");
		return ad.admin_users_list();
	}
	@Override
	public List<AdminUserMovieReservation> admin_movie_list() {
		System.out.println("AdminServiceImpl 15 admin_movie_list start.....");
		return ad.admin_movie_list();
	}
	@Override
	public int admin_mvrs_count(int m_num) {
		return ad.admin_mvrs_count(m_num);
	}
	@Override
	public void admin_movie_close(String m_num) {
		System.out.println("AdminServiceImpl 17 admin_movie_close start.....");
		ad.admin_movie_close(m_num);
	}
	@Override
	public void admin_insert_movie(AdminUserMovieReservation aumr) {
		System.out.println("AdminServiceImpl 18 admin_insert_movie start.....");
		ad.admin_insert_movie(aumr);
	}
	@Override
	public void admin_insert_sm(AdminUserMovieReservation aumr) {
		System.out.println("AdminServiceImpl 19 admin_insert_sm start.....");
		ad.admin_insert_sm(aumr);
	}
	@Override
	public void admin_genre_insert(AdminUserMovieReservation aumr) {
		System.out.println("AdminServiceImpl 20 admin_genre_insert start.....");
		ad.admin_genre_insert(aumr);
	}
	@Override
	public void admin_m_img_insert(AdminUserMovieReservation aumr) {
		System.out.println("AdminServiceImpl 21 admin_m_img_insert start.....");
		ad.admin_m_img_insert(aumr);
	}
	@Override
	public void admin_m_img_insert2(AdminUserMovieReservation aumr) {
		System.out.println("AdminServiceImpl 22 admin_m_img_insert2 start.....");
		ad.admin_m_img_insert2(aumr);
	}
	@Override
	public void admin_common_insert(AdminUserMovieReservation aumr) {
		System.out.println("AdminServiceImpl 23 admin_common_insert start.....");
		ad.admin_common_insert(aumr);
	}
	@Override
	public void admin_stillcut_insert(AdminUserMovieReservation aumr) {
		System.out.println("AdminServiceImpl 24 admin_stillcut_insert start.....");
		ad.admin_stillcut_insert(aumr);
	}
	@Override
	public AdminUserMovieReservation admin_movie_update_select(AdminUserMovieReservation aumr) {
		System.out.println("AdminServiceImpl 25 admin_movie_update_select start.....");
		return ad.admin_movie_update_select(aumr);
	}
	@Override
	public void admin_movie_update(AdminUserMovieReservation aumr) {
		System.out.println("AdminServiceImpl 26 admin_movie_update start.....");
		ad.admin_movie_update(aumr);
	}
	@Override
	public void admin_genre_update(AdminUserMovieReservation aumr) {
		System.out.println("AdminServiceImpl 27 admin_genre_update start.....");
		ad.admin_genre_update(aumr);
	}
	@Override
	public void admin_stillcut_delete(AdminUserMovieReservation aumr) {
		System.out.println("AdminServiceImpl 28 admin_stillcut_delete start.....");
		ad.admin_stillcut_delete(aumr);
	}
	@Override
	public void admin_stillcut_update(AdminUserMovieReservation aumr, String[] admin_stilcut) {
		System.out.println("AdminServiceImpl 29 admin_stillcut_update start.....");
		ad.admin_stillcut_update(aumr, admin_stilcut);
	}
}
