package oracle.java.s20200503.model;

public class Screen {
	private int sc_num;	
	private String s_theater;	
	
	//
	private int m_num;
	
	public int getM_num() {
		return m_num;
	}
	public void setM_num(int m_num) {
		this.m_num = m_num;
	}
	public int getSc_num() {
		return sc_num;
	}
	public void setSc_num(int sc_num) {
		this.sc_num = sc_num;
	}
	public String getS_theater() {
		return s_theater;
	}
	public void setS_theater(String s_theater) {
		this.s_theater = s_theater;
	}
	
}
