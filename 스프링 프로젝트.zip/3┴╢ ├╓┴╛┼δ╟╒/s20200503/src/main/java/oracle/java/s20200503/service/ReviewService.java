package oracle.java.s20200503.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.java.s20200503.model.Report;
import oracle.java.s20200503.model.Review;

public interface ReviewService {

	int rpCheck(Map<String, Integer> map);

	int report(Map<String , String> map);

	int total(int m_num);

	List<Review> rwList(Review review);

	int rsInsert(Review review);

	int reviewUpdate(HashMap<String, Object> hm);

	int reviewDelete(int rw_num);

	int rwOneSelect(Review review);

}
