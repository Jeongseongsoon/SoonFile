package oracle.java.s20200503.dao;


import java.util.List;

import oracle.java.s20200503.model.AdminUserMovieReservation;
import oracle.java.s20200503.model.MovieReviewReport;
import oracle.java.s20200503.model.Report;
import oracle.java.s20200503.model.Reservation;
import oracle.java.s20200503.model.Review;
import oracle.java.s20200503.model.Users;


public interface AdminDao {
	int 							sales_count();
	List<Integer> 					sales_price();
	List<Integer>					year_search_price(String selected_year);
	int 							year_search_count(String selected_year);
	List<Integer> 					month_search_price(String yearmonth);
	int 							month_search_count(String yearmonth);
	List<Integer> 					day_search_list(String selected_day);
	int 							day_search_count(String selected_day);
	List<MovieReviewReport> 		report_list();
	List<Review> 					user_rw_impormation_list(String u_num);
	void 							ben(String u_num, int g_num);
	List<Report> 					user_rp_impormation_list(String u_num);
	List<MovieReviewReport> 		admin_search_list(String admin_search_content, int select);
	List<AdminUserMovieReservation> admin_users_list();
	List<AdminUserMovieReservation> admin_movie_list();
	int 							admin_mvrs_count(int m_num);
	void 							admin_movie_close(String m_num);
	void 							admin_insert_movie(AdminUserMovieReservation aumr);
	void 							admin_insert_sm(AdminUserMovieReservation aumr);
	void 							admin_genre_insert(AdminUserMovieReservation aumr);
	void 							admin_m_img_insert(AdminUserMovieReservation aumr);
	void 							admin_m_img_insert2(AdminUserMovieReservation aumr);
	void 							admin_common_insert(AdminUserMovieReservation aumr);
	void 							admin_stillcut_insert(AdminUserMovieReservation aumr);
	AdminUserMovieReservation		admin_movie_update_select(AdminUserMovieReservation aumr);
	void 							admin_movie_update(AdminUserMovieReservation aumr);
	void 							admin_genre_update(AdminUserMovieReservation aumr);
	void 							admin_stillcut_update(AdminUserMovieReservation aumr, String[] admin_stilcut);
	void 							admin_stillcut_delete(AdminUserMovieReservation aumr);


}
