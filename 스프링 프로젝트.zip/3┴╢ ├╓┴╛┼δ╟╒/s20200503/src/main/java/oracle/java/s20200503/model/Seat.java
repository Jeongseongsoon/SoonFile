package oracle.java.s20200503.model;

//�¼�
public class Seat {
	private int s_num;	//�¼� ��ȣ
	private int sc_num;	//��ũ�� ��ȣ
	private String s_col;	//��
	private String s_row;	//��
	
	public int getS_num() {
		return s_num;
	}
	public void setS_num(int s_num) {
		this.s_num = s_num;
	}
	public int getSc_num() {
		return sc_num;
	}
	public void setSc_num(int sc_num) {
		this.sc_num = sc_num;
	}
	public String getS_col() {
		return s_col;
	}
	public void setS_col(String s_col) {
		this.s_col = s_col;
	}
	public String getS_row() {
		return s_row;
	}
	public void setS_row(String s_row) {
		this.s_row = s_row;
	}
	
}
