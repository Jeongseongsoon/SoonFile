package oracle.java.s20200503.model;


public class Report {
	private int rw_num;
	private int rp_u_num;	
	private String rp_title;	
	private String rp_content;	
	
	public int getRw_num() {
		return rw_num;
	}
	public void setRw_num(int rw_num) {
		this.rw_num = rw_num;
	}
	public int getRp_u_num() {
		return rp_u_num;
	}
	public void setRp_u_num(int rp_u_num) {
		this.rp_u_num = rp_u_num;
	}
	public String getRp_title() {
		return rp_title;
	}
	public void setRp_title(String rp_title) {
		this.rp_title = rp_title;
	}
	public String getRp_content() {
		return rp_content;
	}
	public void setRp_content(String rp_content) {
		this.rp_content = rp_content;
	}
	
}
