package oracle.java.s20200503.dao;

public interface PaymentDao {

}
