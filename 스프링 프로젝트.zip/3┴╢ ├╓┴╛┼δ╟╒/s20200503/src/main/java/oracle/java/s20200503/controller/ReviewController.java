package oracle.java.s20200503.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import oracle.java.s20200503.model.Movie;
import oracle.java.s20200503.model.Report;
import oracle.java.s20200503.model.Review;
import oracle.java.s20200503.service.MovieService;
import oracle.java.s20200503.service.ReportService;
import oracle.java.s20200503.service.ReviewService;
import oracle.java.s20200503.service.RwPaging;

@Controller
public class ReviewController {
	
	@Autowired
	private ReviewService rs;

	@Autowired
	private ReportService rps;
	
	@Autowired
	private MovieService ms;
	
	@RequestMapping(value="review")
	public String review(HttpServletRequest request, int m_num, Review review, String currentPage, Model model) {
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
		int total = rs.total(m_num);
		
		RwPaging pg = new RwPaging(total, currentPage);
		
		review.setStart(pg.getStart());
		review.setEnd(pg.getEnd());

		Movie movie = ms.detail(m_num);
		model.addAttribute("movieImg", movie);
		
		List<Review> rwList = rs.rwList(review);
		System.out.println("review rwList.size() ->" + rwList.size());
		model.addAttribute("rwList", rwList);
		model.addAttribute("movie",m_num);

		model.addAttribute("pg", pg);
		
		return "review";
	}
	
	@RequestMapping(value="reviewSubmit")
	public String reviewSubmit(HttpServletRequest request, int m_num, Review review, Model model) {
		
		String rw_starPoint = request.getParameter("star-input");
		review.setRw_starPoint(Integer.parseInt(rw_starPoint));

		int result = rs.rsInsert(review);
		
		return "redirect:review.do?m_num=" + m_num;
	}
	
	@RequestMapping(value="getReviewUpdate", produces = "application/text;charset=UTF-8")
	@ResponseBody
	public String getReviewUpdate(int rw_num, String rw_content, Model model) {
		
		HashMap<String, Object> hm = new HashMap<String, Object>();
		
		hm.put("rwn", rw_num);
		hm.put("rwc", rw_content);
		
		// 수정 성공하면  1, 실패시 0
		int updateCnt = rs.reviewUpdate(hm);
		String updateResult = "";
		if  (updateCnt == 1) {
			updateResult = "수정되었습니다";
		} else { 
			updateResult = "수정 실패 되었습니다";
		}
		return updateResult;
	}
	
	@RequestMapping(value="getReviewDelete", produces="application/text;charset=UTF-8")
	@ResponseBody
	public String getReviewDelete(int rw_num, Model model) {
		
		int result = rs.reviewDelete(rw_num);
		
		String deleteResult = null;
		
		if  (result == 1) {
			deleteResult = "1";
			System.out.println("삭제 썽공");
			return "review.do";
		}
		else { 
			deleteResult = "0";
		}
		return deleteResult;
	}
	
	@RequestMapping("/report")
	@ResponseBody
	public int report(String u_num, String rw_num, String rp_title, String rp_content) {
		System.out.println("report()");
		Map<String, String> map = new HashMap<String, String>();
		map.put("u_num", u_num);
		map.put("rw_num",rw_num); 
		map.put("rp_title", rp_title);
		map.put("rp_content",rp_content);
		
		int result = rs.report(map);
		System.out.println("신고됐는지 "+result);
		
		return result;
	}
	
	@RequestMapping(value = "/rpCheck")
	@ResponseBody
	public int rpCheck(int u_num, int rw_num) {
		System.out.println("ReviewController rpCheck()");
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("u_num", u_num);
		map.put("rw_num",rw_num); 
		
		int result = rs.rpCheck(map);
		//int result = 1;
		System.out.println(result);
		
		return result;
	}
}
