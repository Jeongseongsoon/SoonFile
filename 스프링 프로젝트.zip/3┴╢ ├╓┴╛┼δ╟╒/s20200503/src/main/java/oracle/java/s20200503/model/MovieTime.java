package oracle.java.s20200503.model;

//��ȭ �󿵽ð� ���� 
public class MovieTime {
	private int mt_num;	//�ð� ��ȣ
	private String mt_stime;	//��ȭ ���� �ð�
	private String mt_etitme;	//��ȭ ���� �ð�
	private int m_num;	//��ȭ ��ȣ
	private int sc_num;	//��ũ�� ��ȣ 
	
	public int getMt_num() {
		return mt_num;
	}
	public void setMt_num(int mt_num) {
		this.mt_num = mt_num;
	}
	public String getMt_stime() {
		return mt_stime;
	}
	public void setMt_stime(String mt_stime) {
		this.mt_stime = mt_stime;
	}
	public String getMt_etitme() {
		return mt_etitme;
	}
	public void setMt_etitme(String mt_etitme) {
		this.mt_etitme = mt_etitme;
	}
	public int getM_num() {
		return m_num;
	}
	public void setM_num(int m_num) {
		this.m_num = m_num;
	}
	public int getSc_num() {
		return sc_num;
	}
	public void setSc_num(int sc_num) {
		this.sc_num = sc_num;
	}
	
}
