package oracle.java.s20200503.dao;


import java.util.List;
import java.util.Map;

import oracle.java.s20200503.model.Comm;
import oracle.java.s20200503.model.Movie;
import oracle.java.s20200503.model.Report;

public interface MovieDao {

	List<Movie> topList(Movie movie);

	String getM_synop(int m_num);
	
	List<Movie> list(Movie movie);

	List<Movie> movieSearch(String m_title);

	Movie trailer(int m_num);

	String getM_img(int m_num);
	
	Movie detail(int m_num);
	
	String synop(int m_num);

	List<Movie> poster(int m_num);

	/*int bmCheck(Map<String, Integer> map);

	int bmUpdate(Map<String, Integer> map);

	int bmDelete(Map<String, Integer> map);

	List<Integer> bm(int u_num);*/

	List<Comm> carousel();

	Movie movieList(int mNum);


}
