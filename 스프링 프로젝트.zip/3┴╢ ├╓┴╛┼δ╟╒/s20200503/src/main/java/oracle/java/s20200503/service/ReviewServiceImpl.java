package oracle.java.s20200503.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import oracle.java.s20200503.dao.ReviewDao;
import oracle.java.s20200503.model.Report;
import oracle.java.s20200503.model.Review;

@Service
public class ReviewServiceImpl implements ReviewService {

	@Autowired
	private ReviewDao rd;

	@Override
	public int rpCheck(Map<String, Integer> map) {
		return rd.rpCheck(map);
	}

	@Override
	public int report(Map<String, String> map) {
		return rd.report(map);
	}

	@Override
	public int total(int m_num) {
		return rd.total(m_num);
	}

	@Override
	public List<Review> rwList(Review review) {
		return rd.rwList(review);
	}

	@Override
	public int rsInsert(Review review) {
		return rd.rsInsert(review);
	}

	@Override
	public int reviewUpdate(HashMap<String, Object> hm) {
		return rd.reviewUpdate(hm);
	}

	@Override
	public int reviewDelete(int rw_num) {
		return rd.reviewDelete(rw_num);
	}

	@Override
	public int rwOneSelect(Review review) {
		return rd.rwOneSelect(review);
	}






}
