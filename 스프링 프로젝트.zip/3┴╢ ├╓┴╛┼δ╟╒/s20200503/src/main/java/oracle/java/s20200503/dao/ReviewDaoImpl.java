package oracle.java.s20200503.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import oracle.java.s20200503.model.Report;
import oracle.java.s20200503.model.Review;

@Repository
public class ReviewDaoImpl implements ReviewDao {

	@Autowired
	private SqlSession session;

	@Override
	public int rpCheck(Map<String, Integer> map) {
		return session.selectOne("rpCheck", map);
	}

	@Override
	public int report(Map<String, String> map) {
		return session.insert("report", map);
	}

	@Override
	public int total(int m_num) {
		return session.selectOne("total",m_num);
	}

	@Override
	public List<Review> rwList(Review review) {
		System.out.println("ReviewDaoImpl rwList Start...");
		return session.selectList("listAll", review);
	}

	@Override
	public int rsInsert(Review review) {
		int kk = 0;
		try {
			kk = session.insert("rsInsert", review);

		} catch (Exception e) {
			System.out.println("ReviewDaoImpl  rsInsert e.getMessage() ->"+e.getMessage());
		}

		return kk;
	}

	@Override
	public int reviewUpdate(HashMap<String, Object> hm) {
		int result = 0;
		try {
			session.update("rwUpdate", hm);
			result = 1;
		} catch (Exception e) {
			System.out.println("ReviewDaoImpl reviewUpdate e.getMessage()->"+e.getMessage());
			result = 0;
		}
		return result;
	}

	@Override
	public int reviewDelete(int rw_num) {
		return session.delete("rwDelete", rw_num);
	}

	@Override
	public int rwOneSelect(Review review) {
		return session.selectOne("rwOneSelect", review);
	}

}
