package oracle.java.s20200503.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Reservation {
	
	private int r_num;			// 예매번호
	private int u_num;			// 회원번호
	private Date r_movDate;		// 영화날짜
	private String r_resPeople;	// 예매인원	
	private int p_num;			// 결제번호
	private int p_price;		// 총결제액
	private Date p_date;		// 결제일자	
 	private String u_id;
	
 	private String r_movDateU;  //문자열 타입 r_movDate
 	private String p_dateU;     //문자열 타입 p_date
 	
	
	
	
	private int m_num;			// 영화번호
	private String m_title;		// 영화제목
	private int m_age;			// 연령제한
	private String m_synop;
	private String m_trailer;
	private Date m_stdate;
	
	private int s_num;		//좌석번호
	private String s_col;		// 열
	private String s_row;		// 행

	private int sc_num;			// 스크린번호
	private String s_theater;	// 상영관
	@JsonFormat(shape= JsonFormat.Shape.STRING, pattern="yyyy-MM-dd", timezone="Asia/Seoul")
	private Date s_start;
	@JsonFormat(shape= JsonFormat.Shape.STRING, pattern="yyyy-MM-dd", timezone="Asia/Seoul")
	private Date s_end;
	private int mt_num;			// 시간번호
	private String mt_stime;	// 영화시작시간
	private String mt_etime;	// 영화시작시간
	
	// 관리자가 예약된 총매출과 총티켓 수 출력을 위해 선언
	private Integer total_sales;
	private Integer total_tiket;
	
	
	public String getR_movDateU() {
		return r_movDateU;
	}
	public void setR_movDateU(String r_movDateU) {
		this.r_movDateU = r_movDateU;
	}
	public String getP_dateU() {
		return p_dateU;
	}
	public void setP_dateU(String p_dateU) {
		this.p_dateU = p_dateU;
	}
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public int getS_num() {
		return s_num;
	}
	public void setS_num(int s_num) {
		this.s_num = s_num;
	}
	public String getS_col() {
		return s_col;
	}
	public void setS_col(String s_col) {
		this.s_col = s_col;
	}
	public String getS_row() {
		return s_row;
	}
	public void setS_row(String s_row) {
		this.s_row = s_row;
	}
	
	public String getMt_etime() {
		return mt_etime;
	}
	public void setMt_etime(String mt_etime) {
		this.mt_etime = mt_etime;
	}
	public int getR_num() {
		return r_num;
	}
	public void setR_num(int r_num) {
		this.r_num = r_num;
	}
	public int getU_num() {
		return u_num;
	}
	public void setU_num(int u_num) {
		this.u_num = u_num;
	}
	public Date getR_movDate() {
		return r_movDate;
	}
	public void setR_movDate(Date r_movDate) {
		this.r_movDate = r_movDate;
	}
	public String getR_resPeople() {
		return r_resPeople;
	}
	public void setR_resPeople(String r_resPeople) {
		this.r_resPeople = r_resPeople;
	}
	public int getP_num() {
		return p_num;
	}
	public void setP_num(int p_num) {
		this.p_num = p_num;
	}
	public int getP_price() {
		return p_price;
	}
	public void setP_price(int p_price) {
		this.p_price = p_price;
	}
	public Date getP_date() {
		return p_date;
	}
	public void setP_date(Date p_date) {
		this.p_date = p_date;
	}
	public int getM_num() {
		return m_num;
	}
	public void setM_num(int m_num) {
		this.m_num = m_num;
	}
	public String getM_title() {
		return m_title;
	}
	public void setM_title(String m_title) {
		this.m_title = m_title;
	}
	public int getM_age() {
		return m_age;
	}
	public void setM_age(int m_age) {
		this.m_age = m_age;
	}
	public String getM_synop() {
		return m_synop;
	}
	public void setM_synop(String m_synop) {
		this.m_synop = m_synop;
	}
	public String getM_trailer() {
		return m_trailer;
	}
	public void setM_trailer(String m_trailer) {
		this.m_trailer = m_trailer;
	}
	public Date getM_stdate() {
		return m_stdate;
	}
	public void setM_stdate(Date m_stdate) {
		this.m_stdate = m_stdate;
	}
	public int getSc_num() {
		return sc_num;
	}
	public void setSc_num(int sc_num) {
		this.sc_num = sc_num;
	}
	public String getS_theater() {
		return s_theater;
	}
	public void setS_theater(String s_theater) {
		this.s_theater = s_theater;
	}
	public Date getS_start() {
		return s_start;
	}
	public void setS_start(Date s_start) {
		this.s_start = s_start;
	}
	public Date getS_end() {
		return s_end;
	}
	public void setS_end(Date s_end) {
		this.s_end = s_end;
	}
	public int getMt_num() {
		return mt_num;
	}
	public void setMt_num(int mt_num) {
		this.mt_num = mt_num;
	}
	public String getMt_stime() {
		return mt_stime;
	}
	public void setMt_stime(String mt_stime) {
		this.mt_stime = mt_stime;
	}
	public Integer getTotal_sales() {
		return total_sales;
	}
	public void setTotal_sales(Integer total_sales) {
		this.total_sales = total_sales;
	}
	public Integer getTotal_tiket() {
		return total_tiket;
	}
	public void setTotal_tiket(Integer total_tiket) {
		this.total_tiket = total_tiket;
	}
	
}
