package service.partAdd;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Part;
import dao.PartDao;
import service.CommandProcess;

public class PartAddUpdateFormAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 1. get -> order_num
		// 2. dao od선언
		// 3. od select
		// 4. 저장 -> pageunm, order

		try {
			request.setCharacterEncoding("utf-8");
			int p_code = Integer.parseInt(request.getParameter("p_code"));
			String pageNum = request.getParameter("pageNum");

			
			PartDao pd = PartDao.getInstance();
			Part part = pd.select(p_code);

						
			request.setAttribute("pageNum", pageNum);
			request.setAttribute("part", part);
			request.setAttribute("p_code", p_code);

			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "partAdd/partAddUpdateForm.jsp";
	}

}
