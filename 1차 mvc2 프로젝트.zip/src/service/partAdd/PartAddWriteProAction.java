package service.partAdd;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Part;
import dao.PartDao;
import service.CommandProcess;

public class PartAddWriteProAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1. get -> num
		// 2. PartDao pd Instance
		// 3. int result = pd.insert(part);
		// 4. 저장 ->
		try {

			request.setCharacterEncoding("utf-8");
			String pageNum = request.getParameter("pageNum");
			Part part = new Part();

			part.setP_code(Integer.parseInt(request.getParameter("p_code")));
			part.setP_name(request.getParameter("p_name"));
			part.setP_cost(Integer.parseInt(request.getParameter("p_cost")));
						
			PartDao pd = PartDao.getInstance();// DB			
			int result = pd.insert(part);			
			request.setAttribute("result", result);
			request.setAttribute("pageNum", pageNum);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "partAdd/partAddWritePro.jsp";
	}

}
