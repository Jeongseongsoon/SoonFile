package service.board;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Board;
import dao.BoardDao;
import dao.Emp;
import dao.EmpDao;
import service.CommandProcess;

public class BoardContentAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			int board_num = Integer.parseInt(request.getParameter("board_num"));
			int startNum = Integer.parseInt(request.getParameter("startNum"));
			String pageNum = request.getParameter("pageNum");
			BoardDao bd = BoardDao.getInstance();
			EmpDao ed = EmpDao.getInstance();
			
			Board board = bd.boardselect(board_num);
			int emp_num = board.getEmp_num();
			
			Emp emp = ed.boardselect(emp_num);
			
			request.setAttribute("startNum", startNum);
			request.setAttribute("emp", emp);
			request.setAttribute("board_num", board_num);
			request.setAttribute("pageNum", pageNum);
			request.setAttribute("board", board);
		
		} catch(Exception e) {System.out.println(e.getMessage());}
		return "board/boardContent.jsp";
	}

	}
