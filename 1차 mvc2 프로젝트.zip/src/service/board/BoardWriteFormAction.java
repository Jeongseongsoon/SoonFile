package service.board;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.CommandProcess;


public class BoardWriteFormAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			int board_num = 0;
			String pageNum = request.getParameter("pageNum");
			if(pageNum == null) pageNum = "1";
			if(request.getParameter("board_num") != null) {
				board_num = Integer.parseInt(request.getParameter("board_num"));
			
			}
			request.setAttribute("board_num", board_num);
			request.setAttribute("pageNum", pageNum);
		} catch(Exception e) {System.out.println(e.getMessage());}
		return "board/boardWriteForm.jsp";
	}

}
