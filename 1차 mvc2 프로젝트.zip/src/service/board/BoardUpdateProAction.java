package service.board;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Board;
import dao.BoardDao;
import service.CommandProcess;

public class BoardUpdateProAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {

			request.setCharacterEncoding("utf-8");
			String pageNum = request.getParameter("pageNum");

			Board board = new Board();

			board.setBoard_num(Integer.parseInt(request.getParameter("board_num")));
			board.setBoard_title(request.getParameter("board_title"));
			board.setBoard_content(request.getParameter("board_content"));
			BoardDao bd = BoardDao.getInstance();
			int result = bd.boardupdate(board);
			request.setAttribute("result", result);
			request.setAttribute("board_num", board.getBoard_num());
			request.setAttribute("pageNum", pageNum);
		} catch(Exception e) {
			System.out.println(e.getMessage());
			
		}
		return "board/boardUpdatePro.jsp";
	}

}
