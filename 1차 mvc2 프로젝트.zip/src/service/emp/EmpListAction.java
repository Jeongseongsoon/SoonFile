package service.emp;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Emp;
import dao.EmpDao;
import service.CommandProcess;

public class EmpListAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			EmpDao ed = EmpDao.getInstance();
			String[] dept_num = request.getParameterValues("dept_num");
			String pageNum = request.getParameter("pageNum");
			String emp_kind = request.getParameter("emp_kind");
			String emp_kindSelect = "";
			String totdept_num = request.getParameter("dept_num_str");
			
			if(totdept_num ==null) {
				totdept_num = "";
			}
		
			if(emp_kind==null && dept_num == null) {
				emp_kindSelect = "emp_joindate is not null and emp_retireDate is null";
				totdept_num = "100,200,300,400";
				emp_kind = "emp_join";
			} else {
				for (int i = 0; i < dept_num.length; i++) {
					if(i == 0) {
						totdept_num = dept_num[i];
					} else {				
						totdept_num = totdept_num +","+ dept_num[i] ;
					}
				}
				switch (emp_kind) {
				case "emp_join":
					emp_kindSelect = "emp_joindate is not null and emp_retiredate is null";
					break;
				case "emp_retire":
					emp_kindSelect = "emp_retiredate is not null";
					break;
				case "emp_all" :
					emp_kindSelect = "emp_joindate is not null";
					break;
				default:
					return "EmpList.jsp";
				}
			}
			
			String select = "select * from emp where dept_num in (" + totdept_num + ") and " + emp_kindSelect ;
			int totCnt = ed.getTotalCnt(select);
			
			if (pageNum == null || pageNum.equals("")) {
				pageNum= "1";
			}
			int currentPage = Integer.parseInt(pageNum);
			int pageSize = 10;
			int blockSize = 10;
			int startRow = (currentPage -1) * pageSize +1; //시작 로우 번호
			int endRow = startRow + pageSize -1; // 끝 로우 번호
			int startNum = totCnt - startRow +1; //페이지별 첫 시작 로우번호
			int pageCnt = (int)Math.ceil((double)totCnt/pageSize);

			List<Emp> list = ed.listCheck(startRow, endRow, emp_kindSelect, totdept_num);

			int startPage = (int)(currentPage-1)/blockSize*blockSize +1;
			int endPage = startPage + blockSize -1;
			if(endPage>pageCnt) endPage = pageCnt;
			
			request.setAttribute("list", list);
			request.setAttribute("totCnt", totCnt);
			request.setAttribute("pageNum", pageNum);
			request.setAttribute("currentPage", currentPage);
			request.setAttribute("startNum", startNum);
			request.setAttribute("blockSize", blockSize);
			request.setAttribute("pageCnt", pageCnt);
			request.setAttribute("startNum", startNum);
			request.setAttribute("endPage", endPage);
			request.setAttribute("startPage", startPage);
			request.setAttribute("emp_kind", emp_kind);
			request.setAttribute("dept_num", dept_num);
			request.setAttribute("dept_num_str", totdept_num);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "emp/empList.jsp";
	}
}
