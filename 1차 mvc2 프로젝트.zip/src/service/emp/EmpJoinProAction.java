package service.emp;


import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Emp;
import dao.EmpDao;
import service.CommandProcess;

public class EmpJoinProAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {
		try {
			request.setCharacterEncoding("utf-8");
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Emp emp = new Emp();
			
			
			//							sql로 변환	 		포맷 형태로            타입 변환                  스트링 타입         
			emp.setEmp_joinDate(java.sql.Date.valueOf(format.format(format.parse(request.getParameter("emp_joinDate")))));
			emp.setEmp_num(Integer.parseInt(request.getParameter("emp_num")));
			emp.setEmp_name(request.getParameter("emp_name"));
			emp.setDept_num(Integer.parseInt(request.getParameter("dept_num")));
			emp.setEmp_rank(request.getParameter("emp_rank"));
			emp.setEmp_tel(request.getParameter("emp_tel"));
			emp.setEmp_address(request.getParameter("emp_address"));
			emp.setEmp_pw(request.getParameter("emp_pw"));
			
			EmpDao ed = EmpDao.getInstance();
			int result = ed.insert(emp);
			request.setAttribute("result", result);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "emp/empJoinPro.jsp";
	}
}
