package service.emp;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Dept;
import dao.DeptDao;
import dao.Emp;
import dao.EmpDao;
import service.CommandProcess;

public class EmpUpdateFormAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
		int emp_num = Integer.parseInt(request.getParameter("emp_num"));
		EmpDao ed = EmpDao.getInstance();
		Emp emp = ed.select(emp_num);
		DeptDao dd = DeptDao.getInstance();
		List<Dept> dept_list = dd.list();
		request.setAttribute("emp", emp);
		request.setAttribute("dept_list", dept_list);
		
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "emp/empUpdateForm.jsp";
	}
}
