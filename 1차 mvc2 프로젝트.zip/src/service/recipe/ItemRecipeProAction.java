package service.recipe;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Item;
import dao.ItemDao;
import dao.Part;
import dao.PartDao;
import dao.Recipe;
import dao.RecipeDao;
import service.CommandProcess;

public class ItemRecipeProAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			request.setCharacterEncoding("utf-8");

			int result = 0;
			Item item = new Item();
			Recipe recipe = new Recipe();

			ItemDao id = ItemDao.getInstance();
			RecipeDao rd = RecipeDao.getInstance();
			PartDao pd = PartDao.getInstance();

			// get p_code(array)
			String[] p_code = request.getParameterValues("p_code");
			String[] need_count = request.getParameterValues("part_num");

			item.setItem_code(Integer.parseInt(request.getParameter("item_code")));
			item.setItem_name(request.getParameter("item_name"));
			item.setItem_cost(Integer.parseInt(request.getParameter("item_cost")));

			// 제품명 추가
			int result1 = id.insert_item(item);

			recipe.setItem_code(Integer.parseInt(request.getParameter("item_code")));

			for (int i = 0; i < p_code.length; i++) {
				recipe.setP_code(Integer.parseInt(p_code[i]));
				recipe.setNeed_count(Integer.parseInt(need_count[i]));

				// 레시피 추가
				result = rd.insert_recipe(recipe);
			}

			List<Part> p_list = pd.list();

			// 파라미터에 저장 :
			request.setAttribute("result", result);
			request.setAttribute("result1", result1);
			request.setAttribute("p_list", p_list);
			request.setAttribute("item_code", recipe.getItem_code());
			request.setAttribute("p_code", recipe.getP_code());
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return "recipe/itemRecipePro.jsp";
	}

}
