package service.recipe;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Part;
import dao.PartDao;
import service.CommandProcess;

public class ItemRecipeFormAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			PartDao pd = PartDao.getInstance();
			
			List<Part> p_list = pd.list();
			
			request.setAttribute("p_list", p_list);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "recipe/itemRecipeForm.jsp";
	}

}
