package service.recipe;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.RecipeDao;
import service.CommandProcess;

public class ItemRecipeDeleteAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			int item_code = Integer.parseInt(request.getParameter("item_code"));
			int p_code = Integer.parseInt(request.getParameter("p_code"));

			RecipeDao rd = RecipeDao.getInstance();
			int result = rd.recipeDelete(item_code, p_code);
			
			request.setAttribute("result", result);
			request.setAttribute("item_code", item_code);
			request.setAttribute("p_code", p_code);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return "recipe/itemRecipeDelete.jsp";
	}

}
