package service.recipe;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Item;
import dao.ItemDao;
import dao.Part;
import dao.PartDao;
import dao.Recipe;
import dao.RecipeDao;
import service.CommandProcess;

public class UpdateRecipeFormAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ItemDao id = ItemDao.getInstance();
		RecipeDao rd = RecipeDao.getInstance();
		PartDao pd = PartDao.getInstance();
		try {
			int item_code = Integer.parseInt(request.getParameter("item_code"));
			Item item = id.select(item_code);
			Recipe recipe = rd.select(item_code);
			Part part = pd.select(item_code);
			List<Part> p_list = pd.list();
			
			request.setAttribute("item", item);
			request.setAttribute("recipe", recipe);
			request.setAttribute("part", part);
			request.setAttribute("p_list", p_list);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "recipe/updateRecipeForm.jsp";
	}

}
