package service.production;

import java.io.IOException;



import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Item;
import dao.ItemDao;
import dao.Order;
import dao.OrderDao;
import dao.Work;
import dao.WorkDao;
import service.CommandProcess;

public class ProductionContentAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			
			int order_num = Integer.parseInt(request.getParameter("order_num"));
			
			OrderDao od = OrderDao.getInstance();
			Order orders = od.productionSelect(order_num);
			ItemDao id = ItemDao.getInstance();
			Item item = id.productionSelect(order_num);
			
			WorkDao wd = WorkDao.getInstance();
			Work work = wd.productionSelect(order_num);
			
			request.setAttribute("order_num", order_num);
			request.setAttribute("orders", orders);
			request.setAttribute("item", item);
			request.setAttribute("work", work);
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		return "production/productionContent.jsp";
	}
}