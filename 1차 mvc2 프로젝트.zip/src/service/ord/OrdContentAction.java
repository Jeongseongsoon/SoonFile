package service.ord;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Item;
import dao.ItemDao;
import dao.Order;
import dao.OrderDao;
import dao.Part;
import dao.PartDao;
import dao.Recipe;
import dao.RecipeDao;
import dao.Work;
import dao.WorkDao;
import service.CommandProcess;

public class OrdContentAction implements CommandProcess {
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			System.out.println("OrdContentAction start...");
			int order_num = Integer.parseInt(request.getParameter("order_num"));
			int item_code = Integer.parseInt(request.getParameter("item_code"));

			OrderDao od = OrderDao.getInstance();
			Order orders = od.ordSelect(order_num);
			

			ItemDao id = ItemDao.getInstance();
			Item item = id.ordSelect(item_code);
			
			WorkDao wd = WorkDao.getInstance();
			Work work= wd.ordSelect3(order_num);
			
			
			
			
			
			
			
			
			
			RecipeDao rd = RecipeDao.getInstance();
			List<Recipe> recipeList = rd.ordRecipeList(item_code);
			
			
			List<Integer> partNeeds = new ArrayList<>();
			for (int i = 0; i < recipeList.size(); i++) {
				partNeeds.add((Integer) recipeList.get(i).getNeed_count() * work.getWork_count());
			}

			
			
			PartDao pd = PartDao.getInstance();
			List<Part> partList = pd.ordPartList(item_code); 
			
			List<String> partNames = new ArrayList<>();
			List<Integer> partCounts = new ArrayList<>();
			for (int i = 0; i < partList.size(); i++) {
				partNames.add((String) partList.get(i).getP_name());
				partCounts.add((Integer) partList.get(i).getP_count());
				}
			


			
			
			List<Integer> totalNeed = new ArrayList<>();

			for(int i = 0 ;i<partCounts.size(); i++){
			totalNeed.add(partCounts.get(i) - partNeeds.get(i));
			}
			System.out.println("totalNeed =>" +totalNeed);
			
			
			
			
			request.setAttribute("orders", orders);
			request.setAttribute("item", item);
			request.setAttribute("work", work);
			request.setAttribute("partNeeds", partNeeds);
			request.setAttribute("partNames", partNames);
			request.setAttribute("partCounts", partCounts);
			request.setAttribute("totalNeed", totalNeed);
			System.out.println("OrdContentAction work->"+work);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "/ord/ordContent.jsp";
	}

}
