package service.ord;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Item;
import dao.ItemDao;
import dao.Order;
import dao.OrderDao;
import dao.Part;
import dao.PartDao;
import dao.Recipe;
import dao.RecipeDao;
import dao.Work;
import dao.WorkDao;
import service.CommandProcess;

public class Ord1Action implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			HttpSession session = request.getSession();
			int order_num = Integer.parseInt(request.getParameter("order_num"));
			int item_code = Integer.parseInt(request.getParameter("item_code"));
			String work_name1 = request.getParameter("work_name1");
			String work_name2 = request.getParameter("work_name2");
			String work_name3 = request.getParameter("work_name3");
			String emp_name = (String) session.getAttribute("emp_name");

			OrderDao od = OrderDao.getInstance();
			Order orders = od.ordSelect(order_num);
			ItemDao id = ItemDao.getInstance();
			Item item = id.ordSelect(item_code);
			WorkDao wd = WorkDao.getInstance();
			Work work = wd.ordSelect3(order_num);

			RecipeDao rd = RecipeDao.getInstance();
			List<Recipe> recipeList = rd.ordRecipeList(item_code);


			List<Integer> partNeeds = new ArrayList<>();
			for (int i = 0; i < recipeList.size(); i++) {
				partNeeds.add((Integer) (recipeList.get(i).getNeed_count() * work.getWork_count()));
			}

			PartDao pd = PartDao.getInstance();
			List<Part> partList = pd.ordPartList(item_code);

			List<Integer> partCounts = new ArrayList<>();
			for (int i = 0; i < partList.size(); i++) {
				partCounts.add((Integer) partList.get(i).getP_count());
			}

			List<Integer> totalNeed = new ArrayList<>();

			for (int i = 0; i < partCounts.size(); i++) {
				totalNeed.add(partCounts.get(i) - partNeeds.get(i));
			}

			request.setAttribute("order_num", order_num);
			request.setAttribute("item_code", item_code);
			request.setAttribute("orders", orders);
			request.setAttribute("work", work);
			request.setAttribute("item", item);

			
			Boolean checkMinus = false;
			for(int i = 0;i<totalNeed.size();i++){
			  if(totalNeed.get(i)< 0){
			    checkMinus = true;
			  }
			}
			if(checkMinus) {
				return "ordFalse.do";
			}else{
				if (work_name1.equals("")) {
					Work work2 = wd.ordStatus(order_num, emp_name);
					Work work3 = wd.ordSelect3(order_num);
					request.setAttribute("work2", work2);
					request.setAttribute("work3", work3);
				}
			}
			


		} catch (Exception e) {

		}

		return "ordOkPro.do?order_num=${orders.order_num}";
	}

}
