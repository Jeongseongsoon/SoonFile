package service.ord;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Item;
import dao.ItemDao;
import dao.Order;
import dao.OrderDao;
import dao.Part;
import dao.PartDao;
import dao.Recipe;
import dao.RecipeDao;
import dao.Work;
import dao.WorkDao;
import service.CommandProcess;

public class Ord3Action implements CommandProcess{

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
				HttpSession session = request.getSession();
				int order_num = Integer.parseInt(request.getParameter("order_num"));
				int item_code = Integer.parseInt(request.getParameter("item_code"));
				int work_count = Integer.parseInt(request.getParameter("work_count"));

				String work_name2 = request.getParameter("work_name2");
				String work_name3 = request.getParameter("work_name3");
				String emp_name = (String) session.getAttribute("emp_name");
				
				OrderDao od = OrderDao.getInstance();
				Order orders = od.ordSelect(order_num);
			
				ItemDao id = ItemDao.getInstance();
				Item item = id.ordSelect(item_code);
			
				WorkDao wd = WorkDao.getInstance();
				Work work= wd.ordSelect3(order_num);
			
				PartDao pd = PartDao.getInstance();
				
				
				RecipeDao rd = RecipeDao.getInstance();
				List<Recipe> recipeList = rd.ordRecipeList(item_code);

				List<Integer> partNeeds = new ArrayList<>();
				for (int i = 0; i < recipeList.size(); i++) {
					partNeeds.add((Integer) recipeList.get(i).getNeed_count() * work.getWork_count());
				}

				
				List<Part> partList = pd.ordPartList(item_code); 
				
				List<String> partNames = new ArrayList<>();
				List<Integer> partCounts = new ArrayList<>();
				List<Integer> partCodes = new ArrayList<>();
				for (int i = 0; i < partList.size(); i++) {
					partNames.add((String) partList.get(i).getP_name());
					partCounts.add((Integer) partList.get(i).getP_count());
					partCodes.add((Integer) partList.get(i).getP_code());
					}
				
				List<Integer> totalNeed = new ArrayList<>();
				for(int i = 0 ;i<partCounts.size(); i++){
				totalNeed.add(partCounts.get(i) - partNeeds.get(i));
				}
				
			
				request.setAttribute("order_num", order_num);
				request.setAttribute("item_code", item_code);
				
				request.setAttribute("orders", orders);
			
				request.setAttribute("work", work);
			
				request.setAttribute("item", item);
				
				
				if(work_name3.equals("")&&!work_name2.equals("")){
			
						Work work2= wd.ordStatus3(order_num, emp_name);
						Work insert = wd.ordInsert(order_num, work_count);
 
					
						request.setAttribute("work2", work2);
					
						Work work3= wd.ordSelect3(order_num);

						for(int i = 0 ;i<totalNeed.size(); i++){
							int remain = totalNeed.get(i);
							int part_code = partCodes.get(i);
							int result = pd.ordUpdate(remain, part_code);							
						}

						request.setAttribute("work3", work3);
						request.setAttribute("insert", insert);

				}else return "ordFalse.do";
		
				
				
				
				
				
			}catch (Exception e) {
			
			}

	return "ordOkPro2.do";
	}

}