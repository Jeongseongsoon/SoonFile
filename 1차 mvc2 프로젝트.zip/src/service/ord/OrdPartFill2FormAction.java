package service.ord;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Part;
import dao.PartDao;
import service.CommandProcess;

public class OrdPartFill2FormAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			int p_code = Integer.parseInt(request.getParameter("p_code"));
			int order_num = Integer.parseInt(request.getParameter("order_num"));
			int item_code = Integer.parseInt(request.getParameter("item_code"));

			
			PartDao pd = PartDao.getInstance();
			Part part = pd.ordSelect(p_code);
			
			
			request.setAttribute("part", part);
			request.setAttribute("p_code", p_code);
			request.setAttribute("order_num", order_num);
			request.setAttribute("item_code", item_code);

			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "ord/ordPartFill2Form.jsp";
	}

}
