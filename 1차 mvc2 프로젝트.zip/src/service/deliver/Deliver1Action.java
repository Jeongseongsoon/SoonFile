package service.deliver;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Item;
import dao.ItemDao;
import dao.Order;
import dao.OrderDao;
import dao.Work;
import dao.WorkDao;
import service.CommandProcess;

public class Deliver1Action implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			HttpSession session = request.getSession();
			int order_num = Integer.parseInt(request.getParameter("order_num"));

			String work_name1 = request.getParameter("work_name1");

			String emp_name = (String) session.getAttribute("emp_name");

			OrderDao od = OrderDao.getInstance();
			Order orders = od.select(order_num);

			ItemDao id = ItemDao.getInstance();
			Item item = id.select(order_num);

			WorkDao wd = WorkDao.getInstance();
			Work work = wd.deliverselect3(order_num);

			request.setAttribute("order_num", order_num);

			request.setAttribute("orders", orders);

			request.setAttribute("work", work);

			request.setAttribute("item", item);

			if (work_name1.equals("")) {

				Work work2 = wd.deliverstatus1(order_num, emp_name);

				request.setAttribute("work2", work2);

				Work work3 = wd.deliverselect3(order_num);

				request.setAttribute("work3", work3);

			} else
				return "deliverfalse.do";

		} catch (Exception e) {
			System.out.println(e.getMessage());

		}

		return "deliverokPro.do?order_num=${orders.order_num}";
	}

}
