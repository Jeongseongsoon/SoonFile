package dao;

import java.sql.Date;

public class Emp {
	private int emp_num;
	private String emp_name;
	private int dept_num;
	private String emp_rank;
	private String emp_tel;
	private String emp_address;
	private String emp_pw;
	private Date emp_joinDate;
	private Date emp_retireDate;

	public Date getEmp_joinDate() {
		return emp_joinDate;
	}

	public void setEmp_joinDate(Date emp_joinDate) {
		this.emp_joinDate = emp_joinDate;
	}

	public Date getEmp_retireDate() {
		return emp_retireDate;
	}

	public void setEmp_retireDate(Date emp_retireDate) {
		this.emp_retireDate = emp_retireDate;
	}

	public int getEmp_num() {
		return emp_num;
	}

	public void setEmp_num(int emp_num) {
		this.emp_num = emp_num;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public int getDept_num() {
		return dept_num;
	}

	public void setDept_num(int dept_num) {
		this.dept_num = dept_num;
	}

	public String getEmp_rank() {
		return emp_rank;
	}

	public void setEmp_rank(String emp_rank) {
		this.emp_rank = emp_rank;
	}

	public String getEmp_tel() {
		return emp_tel;
	}

	public void setEmp_tel(String emp_tel) {
		this.emp_tel = emp_tel;
	}

	public String getEmp_address() {
		return emp_address;
	}

	public void setEmp_address(String emp_address) {
		this.emp_address = emp_address;
	}

	public String getEmp_pw() {
		return emp_pw;
	}

	public void setEmp_pw(String emp_pw) {
		this.emp_pw = emp_pw;
	}
}
