package dao;

public class Recipe {
   private int p_code;
   private int item_code;
   private int need_count;
   
   public int getP_code() {
      return p_code;
   }
   public void setP_code(int p_code) {
      this.p_code = p_code;
   }
   public int getItem_code() {
      return item_code;
   }
   public void setItem_code(int item_code) {
      this.item_code = item_code;
   }
   public int getNeed_count() {
      return need_count;
   }
   public void setNeed_count(int need_count) {
      this.need_count = need_count;
   }
}