package dao;

import java.util.Date;

public class Work {

	private int order_num;
	private int dept_num;
	private Date work1;
	private Date work2;
	private Date work3;
	private String work_name1;
	private String work_name2;
	private String work_name3;
	private int work_count;
	private int work_realcount;
	private int defect_item;
	private int work_status;
	
	
	
	
	public int getWork_status() {
		return work_status;
	}

	public void setWork_status(int work_status) {
		this.work_status = work_status;
	}

	public int getWork_count() {
		return work_count;
	}

	public void setWork_count(int work_count) {
		this.work_count = work_count;
	}

	public int getWork_realcount() {
		return work_realcount;
	}

	public void setWork_realcount(int work_realcount) {
		this.work_realcount = work_realcount;
	}



	public int getOrder_num() {
		return order_num;
	}

	public void setOrder_num(int order_num) {
		this.order_num = order_num;
	}

	public int getDept_num() {
		return dept_num;
	}

	public void setDept_num(int dept_num) {
		this.dept_num = dept_num;
	}

	public Date getWork1() {
		return work1;
	}

	public void setWork1(Date work1) {
		this.work1 = work1;
	}

	public Date getWork2() {
		return work2;
	}

	public void setWork2(Date work2) {
		this.work2 = work2;
	}

	public Date getWork3() {
		return work3;
	}

	public void setWork3(Date work3) {
		this.work3 = work3;
	}

	public String getWork_name1() {
		return work_name1;
	}

	public void setWork_name1(String work_name1) {
		this.work_name1 = work_name1;
	}

	public String getWork_name2() {
		return work_name2;
	}

	public void setWork_name2(String work_name2) {
		this.work_name2 = work_name2;
	}

	public String getWork_name3() {
		return work_name3;
	}

	public void setWork_name3(String work_name3) {
		this.work_name3 = work_name3;
	}

	public int getDefect_item() {
		return defect_item;
	}

	public void setDefect_item(int defect_item) {
		this.defect_item = defect_item;
	}

}
