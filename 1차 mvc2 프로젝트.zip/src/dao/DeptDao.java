package dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DeptDao {
	private static DeptDao instance;
	
	
	private DeptDao() {}
	
	public static DeptDao getInstance() {
		if (instance == null) {
			instance = new DeptDao();
		}
		return instance;
	}
	
	private static Connection getConnection() {
		Connection conn = null;
		try {
			Context ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/OracleDB");
			conn = ds.getConnection();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return conn;
	}

	public List<Dept> list() throws SQLException {
		List<Dept> list = new ArrayList<Dept>();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select * from dept";
		
		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				Dept dept = new Dept();
				dept.setDept_num(rs.getInt("dept_num"));
				dept.setDept_name(rs.getString("dept_name"));
				list.add(dept);
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null) rs.close();
			if (stmt != null) stmt.close();
			if (conn != null) conn.close();
		}
		
		
		return list;
	}

	public Dept select(int dept_num) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		Dept dept = new Dept();
		String sql = "select * from dept where dept_num=?";
		ResultSet rs = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, dept_num);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
			
			dept.setDept_name(rs.getString(2));
			System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"+rs.getString(2));
			}
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
			if (conn != null) conn.close();
		}
		
		
		
		return dept;
	}

	
}













