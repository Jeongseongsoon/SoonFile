package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class RecipeDao {
	private static RecipeDao instance;

	private RecipeDao() {
	}

	public static RecipeDao getInstance() {
		if (instance == null) {
			instance = new RecipeDao();
		}
		return instance;
	}

	private Connection getConnection() {
		Connection conn = null;
		try {
			Context ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/OracleDB");
			conn = ds.getConnection();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return conn;
	}

	public List<Recipe> list() throws SQLException {
		List<Recipe> r_list = new ArrayList<Recipe>();

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;

		String sql = "select * from recipe";

		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				Recipe recipe = new Recipe();
				recipe.setItem_code(rs.getInt("item_code"));
				recipe.setP_code(rs.getInt("p_code"));
				recipe.setNeed_count(rs.getInt("need_count"));
				r_list.add(recipe);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		}

		return r_list;
	}

	public int insert_recipe(Recipe recipe) throws SQLException {
		int result = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "insert into recipe values(?,?,?)";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, recipe.getP_code());
			pstmt.setInt(2, recipe.getItem_code());
			pstmt.setInt(3, recipe.getNeed_count());

			result = pstmt.executeUpdate();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return result;
	}

	public Recipe select(int item_code) throws SQLException {
		Recipe recipe = new Recipe();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;

		String sql = "select * from recipe where item_code=" + item_code;

		try {
			conn = getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				recipe.setItem_code(rs.getInt("item_code"));
				recipe.setNeed_count(rs.getInt("need_count"));
				recipe.setP_code(rs.getInt("p_code"));
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		}

		return recipe;
	}

	public int update(Recipe recipe) throws SQLException {
		int result = 0;

		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "update recipe set need_count=? where item_code=? and p_code=?";
		String sql2 = "insert into recipe values(?, ?, ?)";

		try {
			conn = getConnection();

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, recipe.getNeed_count());
			pstmt.setInt(2, recipe.getItem_code());
			pstmt.setInt(3, recipe.getP_code());

			result = pstmt.executeUpdate();
			pstmt.close();

			if (result != 1) {
				pstmt = conn.prepareStatement(sql2);
				pstmt.setInt(1, recipe.getP_code());
				pstmt.setInt(2, recipe.getItem_code());
				pstmt.setInt(3, recipe.getNeed_count());

				result = pstmt.executeUpdate();
				pstmt.close();

			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}

		return result;
	}

	public int recipeDelete(int item_code, int p_code) throws SQLException {
		int result = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "delete from recipe where item_code=? and p_code=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, item_code);
			pstmt.setInt(2, p_code);

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}

		return result;
	}

	public List<Recipe> ordRecipeList(int item_code) throws SQLException {
		List<Recipe> recipeList = new ArrayList<Recipe>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select p_code, need_count from recipe where item_code=" + item_code + "ORDER BY p_code";
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Recipe recipe = new Recipe();
				recipe.setP_code(rs.getInt("p_code"));
				recipe.setNeed_count(rs.getInt("need_count"));
				recipeList.add(recipe);
			}
		} catch (Exception e) {
		} finally {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn != null)
				conn.close();
		}
		return recipeList;
	}
}
